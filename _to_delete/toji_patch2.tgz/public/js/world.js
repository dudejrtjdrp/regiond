/* world.js — 오픈월드 렌더러. 단일 캔버스에 지형·안개·자원·주민·건물·울타리·아바타·전투를 그린다.
   보이는 청크만 그리고, 지형 도트는 청크 캔버스에 한 번 구워 두었다가 확대해 쓴다.
   ★ 서버가 준 것만 그린다 — 안개 밖의 것은 페이로드에 아예 없다.
   ★ 안개는 서버 확정본과 클라 예측(아바타 둘레)을 겹쳐 본다 (GDD3 §8).
   ★ 이펙트는 GM.fx 가 쥐고 있고, 여기서는 순서만 맞춰 불러 준다. */
(function (global) {
  'use strict';
  var GM = global.GM = global.GM || {};
  var S = GM.state, U = GM.ui;

  var cv = null, ctx = null;
  var W = 960, H = 540;
  var chunkCache = {};
  var CH = 16;
  var BASE = 16;

  var units = {};            // 주민 걷기 연출 (클라 권위)
  var walkIns = [];          // ★ §13-A-4 막 도착한 주민의 이름표 {id,name,t} — 몸이 아니라 표시다
  var lastT = 0, animT = 0;
  var hoverTile = { x: -1, y: -1 };
  var dragBox = null;
  var fencePath = null;      // 울타리 드래그 중인 꺾은선
  var territoryAnim = null;  // {from, to, t}
  var stakePhase = 0;
  var frameTimes = [];       // 프레임 간격 (스모크가 읽는다)
  var workTimes = [];        // 한 프레임을 그리는 데 든 시간 — 60fps 예산(16.7ms) 대비 여유

  /* ══════════ 마운트 ══════════ */
  function mount() {
    cv = U.qs('#world-canvas');
    if (!cv) return;
    resize();
    S.on('world', function () { chunkCache = {}; units = {}; recenter(); });
  }

  function recenter() {
    var t = S.myTown();
    if (t) GM.camera.reset(t.x, t.y);
    else GM.camera.reset();
  }

  function resize() {
    if (!cv) return;
    var host = U.qs('#stage');
    var r = host ? host.getBoundingClientRect() : { width: 960, height: 540 };
    W = Math.max(320, Math.round(r.width || 960));
    H = Math.max(240, Math.round(r.height || 540));
    cv.style.width = W + 'px';
    cv.style.height = H + 'px';
    ctx = U.fitCanvas(cv, W, H);
    GM.camera.setViewport(W, H);
  }

  /* ══════════ 지형 청크 ══════════ */
  function chunkCanvas(cx, cy) {
    var key = cx + ',' + cy;
    if (chunkCache[key]) return chunkCache[key];
    var m = S.S.map;
    if (!m) return null;
    var c = document.createElement('canvas');
    c.width = CH * BASE; c.height = CH * BASE;
    var g = c.getContext('2d');
    if (!g) return null;
    g.imageSmoothingEnabled = false;
    var codes = m.codes;
    for (var y = 0; y < CH; y++) {
      for (var x = 0; x < CH; x++) {
        var wx = cx * CH + x, wy = cy * CH + y;
        if (wx >= m.size || wy >= m.size) continue;
        var code = codes[m.terrain[wy * m.size + wx]] || 'grass';
        var v = GM.atlas.variantAt(wx, wy, 3);
        try { g.drawImage(GM.atlas.terrain(code, v), x * BASE, y * BASE); } catch (e) {}
      }
    }
    chunkCache[key] = c;
    return c;
  }

  function drawTerrain() {
    var m = S.S.map;
    if (!m) return;
    var cam = GM.camera.cam;
    var vis = GM.camera.visible();
    var cx0 = Math.floor(vis.x0 / CH), cx1 = Math.floor(vis.x1 / CH);
    var cy0 = Math.floor(vis.y0 / CH), cy1 = Math.floor(vis.y1 / CH);
    var scale = cam.tile / BASE;
    for (var cy = cy0; cy <= cy1; cy++) {
      for (var cx = cx0; cx <= cx1; cx++) {
        var c = chunkCanvas(cx, cy);
        if (!c) continue;
        var p = GM.camera.worldToScreen(cx * CH - 0.5, cy * CH - 0.5);
        try {
          ctx.drawImage(c, Math.round(p.x), Math.round(p.y),
            Math.ceil(CH * BASE * scale), Math.ceil(CH * BASE * scale));
        } catch (e) {}
      }
    }
  }

  /* ══════════ 자원 군락 바닥 (GDD3 §13-B-1) ══════════
     군락은 '노드 여럿'이 아니라 **지역**이다. 그 지역이 지역으로 읽히려면 발밑이 달라야 한다 —
     숲 군락은 짙은 이끼, 딸기 들은 붉은 기, 바위 지대는 잿빛 자갈, 강가 어장은 젖은 모래.
     지형 청크를 다시 굽지 않고 반투명 원을 얹는다: 지형 캐시를 건드리지 않아 티어업·재접속에도 흔들림이 없다. */
  var CLUSTER_TINT = {
    forest:  { fill: 'rgba(48,84,44,.20)',  edge: 'rgba(48,84,44,.10)' },
    berry:   { fill: 'rgba(150,60,70,.16)', edge: 'rgba(150,60,70,.08)' },
    rock:    { fill: 'rgba(126,132,140,.20)', edge: 'rgba(126,132,140,.09)' },
    water:   { fill: 'rgba(196,178,132,.20)', edge: 'rgba(196,178,132,.09)' },
    fertile: { fill: 'rgba(178,140,58,.18)', edge: 'rgba(178,140,58,.08)' },
    iron:    { fill: 'rgba(150,96,72,.16)', edge: 'rgba(150,96,72,.07)' },
    oil:     { fill: 'rgba(88,72,140,.16)', edge: 'rgba(88,72,140,.07)' }
  };

  function drawClusters() {
    var list = S.clusterList();
    if (!list || !list.length) return;
    var t = GM.camera.cam.tile;
    ctx.save();
    for (var i = 0; i < list.length; i++) {
      var c = list[i];
      var tint = CLUSTER_TINT[c.type];
      if (!tint) continue;
      var rad = (c.r + 1.4) * t;
      if (!GM.camera.onScreen(c.x, c.y, rad * 2)) continue;
      if (S.fogAt(c.x, c.y) < 1) continue;
      var p = GM.camera.worldToScreen(c.x, c.y);
      var g = ctx.createRadialGradient(p.x, p.y, Math.max(1, rad * 0.25), p.x, p.y, rad);
      g.addColorStop(0, tint.fill);
      g.addColorStop(0.68, tint.edge);
      g.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(p.x, p.y, rad, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();
  }

  /* ══════════ 전장의 안개 ══════════ */
  function drawFog() {
    var m = S.S.map;
    if (!m) return;
    var cam = GM.camera.cam;
    var vis = GM.camera.visible();
    var t = cam.tile;
    /* ★ §13-A-2 — 「기억하는 땅」의 장막은 화면을 가장 크게 어둡게 만드는 항이다.
       0.42 → 다이얼(기본 0.30)로 완화하고, **건설 모드에서는 더 옅게**(0.18) 덮는다.
       건물을 놓으러 카메라를 옮기면 시야를 벗어나 화면이 훅 어두워지던 것이 이 값 때문이었다. */
    var veil = 'rgba(8,6,16,' + S.fogVeil().toFixed(3) + ')';
    for (var y = vis.y0; y <= vis.y1; y++) {
      var runStart = -1, runVal = -1;
      for (var x = vis.x0; x <= vis.x1 + 1; x++) {
        var v = x > vis.x1 ? -2 : S.fogAt(x, y);
        if (v === runVal) continue;
        if (runStart >= 0 && runVal >= 0 && runVal < 2) {
          var p0 = GM.camera.worldToScreen(runStart - 0.5, y - 0.5);
          ctx.fillStyle = runVal === 0 ? '#0a0710' : veil;
          ctx.fillRect(Math.floor(p0.x), Math.floor(p0.y), Math.ceil((x - runStart) * t) + 1, Math.ceil(t) + 1);
        }
        runStart = x; runVal = v;
      }
    }
  }

  /* ══════════ 영토 · 말뚝 ══════════ */
  /** 티어업 — 말뚝이 새 반경으로 옮겨 박히는 연출 */
  function animateTerritory(from, to) {
    territoryAnim = { from: from, to: to, t: 0 };
  }

  function territoryRadiusNow() {
    var t = S.territory();
    var r = t ? t.radius : 6;
    if (territoryAnim) {
      var k = U.clamp(territoryAnim.t / 1.5, 0, 1);
      var e = 1 - Math.pow(1 - k, 3);
      return territoryAnim.from + (territoryAnim.to - territoryAnim.from) * e;
    }
    return r;
  }

  /**
   * ★ 영토 경계 — 원 점선을 걷어 내고 **말뚝 + 밧줄**로 다시 그린다 (GDD3 §11-5).
   *   ① 안쪽은 아주 옅게 밝다(우리 땅이라는 감각) ② 경계 가까이는 그라데이션으로 어두워진다
   *   ③ 일정 간격으로 말뚝을 박고 ④ 말뚝 사이를 밧줄이 늘어져 잇는다(사이사이 처짐).
   *   티어업 때 말뚝이 하나씩 옮겨 박히는 연출은 그대로 살아 있다.
   */
  function drawTerritory() {
    var t = S.territory();
    if (!t || t.cx == null) return;
    var c = GM.camera.worldToScreen(t.cx, t.cy);
    var rr = territoryRadiusNow();
    var tile = GM.camera.cam.tile;
    var r = rr * tile;
    if (r <= 2) return;

    /* ① 내부 밝기 + ② 경계 그라데이션 — 선이 아니라 '땅의 결'로 안팎을 가른다 */
    ctx.save();
    var inner = Math.max(0, r - Math.max(6, tile * 0.9));
    var g = ctx.createRadialGradient(c.x, c.y, inner, c.x, c.y, r);
    g.addColorStop(0, 'rgba(246,231,180,.045)');
    g.addColorStop(0.72, 'rgba(246,231,180,.03)');
    g.addColorStop(1, 'rgba(58,40,20,.20)');
    ctx.beginPath();
    ctx.arc(c.x, c.y, r, 0, Math.PI * 2);
    ctx.fillStyle = g;
    ctx.fill();
    ctx.restore();

    /* ③④ 말뚝과 밧줄 — 말뚝 간격은 화면에서 일정하게 보이도록 반경에 따라 늘린다 */
    var n = Math.max(10, Math.min(48, Math.round(rr * 1.5)));
    var postW = Math.max(2, Math.round(tile * 0.16));
    var postH = Math.max(6, Math.round(tile * 0.5));
    var pts = [];
    for (var i = 0; i < n; i++) {
      var a = (i / n) * Math.PI * 2 - Math.PI / 2;
      var pop = 0;
      if (territoryAnim) {
        var d = territoryAnim.t - 0.25 - (i / n) * 0.5;
        if (d < 0) { pts.push(null); continue; }        // 아직 안 박힌 말뚝
        pop = Math.max(0, 1 - d * 4);
      }
      pts.push({ x: c.x + Math.cos(a) * r, y: c.y + Math.sin(a) * r, pop: pop });
    }

    /* 밧줄 먼저 — 말뚝 뒤로 지나가야 한다. 두 말뚝 사이가 살짝 늘어진다. */
    ctx.save();
    ctx.strokeStyle = 'rgba(198,166,110,.75)';
    ctx.lineWidth = Math.max(1, tile * 0.055);
    ctx.lineCap = 'round';
    for (var j = 0; j < pts.length; j++) {
      var p0 = pts[j], p1 = pts[(j + 1) % pts.length];
      if (!p0 || !p1) continue;
      var mx = (p0.x + p1.x) / 2, my = (p0.y + p1.y) / 2;
      var sag = Math.max(1.5, tile * 0.1);              // 늘어짐
      var ox = mx - c.x, oy = my - c.y;
      var len = Math.hypot(ox, oy) || 1;
      ctx.beginPath();
      ctx.moveTo(p0.x, p0.y - postH * 0.78);
      ctx.quadraticCurveTo(mx + (ox / len) * sag, my + (oy / len) * sag - postH * 0.7, p1.x, p1.y - postH * 0.78);
      ctx.stroke();
    }
    ctx.restore();

    /* 말뚝 — 나무 기둥 + 밝은 머리. 새로 박히는 순간에는 흙먼지 선이 튄다. */
    ctx.save();
    for (var k = 0; k < pts.length; k++) {
      var p = pts[k];
      if (!p) continue;
      var h = postH * (1 + p.pop * 0.55);
      ctx.fillStyle = 'rgba(20,14,8,.35)';              // 그림자
      ctx.fillRect(p.x - postW, p.y - 1, postW * 2, Math.max(1, postW * 0.7));
      ctx.fillStyle = '#6b4526';
      ctx.fillRect(p.x - postW / 2, p.y - h, postW, h);
      ctx.fillStyle = '#8a5c33';
      ctx.fillRect(p.x - postW / 2, p.y - h, Math.max(1, postW * 0.4), h);
      ctx.fillStyle = p.pop > 0 ? '#f6cf7a' : '#c8a874';
      ctx.fillRect(p.x - postW / 2, p.y - h, postW, Math.max(2, h * 0.2));
      if (p.pop > 0.1) {
        ctx.globalAlpha = p.pop;
        ctx.fillStyle = '#f6e6a8';
        ctx.fillRect(p.x - postW * 1.8, p.y - 1, postW * 3.6, 2);
        ctx.globalAlpha = 1;
      }
    }
    ctx.restore();
  }

  /* ══════════ 울타리 조각 ══════════ */
  /* ★ GDD3 §13-D-5 — 철로. 바닥에 깔린 것이라 건물·사람보다 먼저 그린다. */
  function drawRails() {
    var list = S.rails();
    if (!list.length) return;
    var t = GM.camera.cam.tile;
    for (var i = 0; i < list.length; i++) {
      var r = list[i];
      if (!GM.camera.onScreen(r.x, r.y, t)) continue;
      if (S.fogAt(r.x, r.y) < 1) continue;
      var p = GM.camera.worldToScreen(r.x - 0.5, r.y - 0.5);
      ctx.save();
      /* 침목 — 가로 세 줄 */
      ctx.fillStyle = '#6b4526';
      for (var k = 0; k < 3; k++) {
        ctx.fillRect(Math.round(p.x + t * (0.12 + k * 0.3)), Math.round(p.y + t * 0.2),
                     Math.max(1, Math.round(t * 0.12)), Math.max(1, Math.round(t * 0.6)));
      }
      /* 레일 — 세로 두 줄 */
      ctx.fillStyle = '#9aa4ae';
      ctx.fillRect(Math.round(p.x), Math.round(p.y + t * 0.26), Math.ceil(t), Math.max(1, Math.round(t * 0.1)));
      ctx.fillRect(Math.round(p.x), Math.round(p.y + t * 0.64), Math.ceil(t), Math.max(1, Math.round(t * 0.1)));
      ctx.restore();
    }
  }

  function drawFences() {
    var list = S.fences();
    if (!list.length) return;
    var tile = GM.camera.cam.tile;
    for (var i = 0; i < list.length; i++) {
      var f = list[i];
      var mx = (f.x1 + f.x2) / 2, my = (f.y1 + f.y2) / 2;
      if (!GM.camera.onScreen(mx, my, tile * 2)) continue;
      if (S.fogAt(Math.round(mx), Math.round(my)) < 1) continue;
      var vertical = f.x1 === f.x2;
      var cond = f.condition === undefined ? 1 : f.condition;
      var dmg = f.broken ? 2 : (cond < 0.6 ? 1 : 0);
      var sp = GM.atlas.fence({ vertical: vertical, tier: f.tier, gate: f.gate, damage: dmg });
      var p = GM.camera.worldToScreen(mx - 0.5, my - 0.62);
      ctx.save();
      if (f.broken) ctx.globalAlpha = 0.6;
      try { ctx.drawImage(sp, Math.round(p.x), Math.round(p.y), Math.ceil(tile), Math.ceil(tile)); } catch (e) {}
      ctx.restore();
      if (S.S.selection && S.S.selection.fenceId === f.id) ringAt(mx, my, '#e8a33d', 0.9);
    }
  }

  /* ══════════ 자원 자리 ══════════ */
  function drawNodes() {
    var cam = GM.camera.cam;
    var list = S.nodeList();
    var t = cam.tile;
    for (var i = 0; i < list.length; i++) {
      var n = list[i];
      if (!GM.camera.onScreen(n.x, n.y, t)) continue;
      if (S.fogAt(n.x, n.y) < 1) continue;
      var sh = GM.fx ? GM.fx.nodeShake(n.id) : 0;
      var p = GM.camera.worldToScreen(n.x - 0.5 + sh, n.y - 0.5);
      /* ★ §13-B-3 — 다 캔 자리는 **그루터기**다. 아이콘을 어둡게 덮는 게 아니라 그루터기를 그린다. */
      if (n.depleted) {
        ctx.save();
        ctx.globalAlpha = 0.85;
        try { ctx.drawImage(GM.atlas.stump(n.type), Math.round(p.x), Math.round(p.y), Math.ceil(t), Math.ceil(t)); } catch (e0) {}
        ctx.restore();
        drawRegrowClock(n, p, t);
        continue;
      }
      var sp = GM.atlas.node(n.type, {
        stage: n.stage, rich: n.rich,
        thin: n.ratio !== undefined && n.ratio !== null && n.ratio < 0.4
      });
      /* ★ §13-B-3 — 고갈이 임박하면 **옅어진다**. 남은 양이 fadeAt(35%) 아래로 내려가는 순간부터
         비율에 비례해 투명해지므로, 멀리서도 '저 숲은 곧 끝난다'가 눈으로 읽힌다. */
      var fadeAt = S.regrowCfg() ? S.regrowCfg().fadeAt : 0.35;
      var ratio = (n.ratio == null) ? 1 : n.ratio;
      var faded = ratio < fadeAt;
      if (faded) { ctx.save(); ctx.globalAlpha = 0.42 + 0.58 * (ratio / Math.max(0.01, fadeAt)); }
      try { ctx.drawImage(sp, Math.round(p.x), Math.round(p.y), Math.ceil(t), Math.ceil(t)); } catch (e) {}
      if (faded) ctx.restore();
      if (n.harvestReady) {
        var g = 0.5 + 0.5 * Math.sin(animT / 260 + n.x);
        ctx.save();
        ctx.globalAlpha = 0.35 + g * 0.5;
        ctx.fillStyle = '#f6e6a8';
        ctx.fillRect(p.x + t * 0.34, p.y - t * 0.28, t * 0.3, t * 0.3);
        ctx.restore();
      }
      /* 스윙 진행 — 몇 번 더 치면 되는가 */
      if (n.swings > 0 && n.swingsPerCycle > 1 && t >= 20) {
        var per = n.swingsPerCycle;
        var dotW = Math.max(3, t * 0.14);
        var totalW = per * (dotW + 2) - 2;
        var bx = p.x + (t - totalW) / 2, by = p.y - 6;
        for (var k = 0; k < per; k++) {
          ctx.fillStyle = k < n.swings ? '#f6cf7a' : 'rgba(20,14,8,.5)';
          ctx.fillRect(bx + k * (dotW + 2), by, dotW, 3);
        }
      }
      if (n.workers > 0 && t >= 24) {
        ctx.fillStyle = 'rgba(20,14,8,.6)';
        ctx.fillRect(p.x, p.y + t - 5, t, 5);
        ctx.fillStyle = '#8dbb6d';
        ctx.fillRect(p.x, p.y + t - 5, t * Math.min(1, n.workers / Math.max(1, n.slots)), 5);
      }
    }
  }

  /** 그루터기 위 작은 시계 — 며칠 뒤에 되살아나는지 (§13-B-3) */
  function drawRegrowClock(n, p, t) {
    if (n.respawnAt == null || t < 22) return;
    var left = n.respawnAt - (S.S.view ? S.S.view.day : 0);
    if (!(left > 0)) return;
    ctx.save();
    ctx.globalAlpha = 0.8;
    ctx.fillStyle = 'rgba(20,14,8,.6)';
    ctx.fillRect(p.x + t * 0.28, p.y - t * 0.26, t * 0.44, t * 0.3);
    ctx.fillStyle = '#8dbb6d';
    ctx.font = Math.max(8, Math.round(t * 0.26)) + 'px Galmuri11, monospace';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(String(Math.ceil(left)), p.x + t * 0.5, p.y - t * 0.11);
    ctx.restore();
  }

  /* ══════════ 들에 사는 것들 (GDD3 §13-C) ══════════
     ★ 위치의 주인은 **서버**다(주민과 정반대다 — 주민은 클라가 쥔다).
       서버는 1초에 한 번만 좌표를 보내므로, 그 값을 그대로 찍으면 짐승이 1초에 한 번 튄다.
       그래서 화면은 제 렌더 좌표를 따로 들고 서버 좌표로 **다가간다**(lerp).
       처음 본 놈과 너무 멀리 벌어진 놈만 스냅한다 — §12-11 텔레포트 사고의 해법을 그대로 뒤집어 쓴 것이다. */
  var wild = {};
  var WILD_SNAP = 12;

  /* ★ GDD3 §14-3 — 뚝뚝 끊기던 까닭과 고친 규칙.
     옛 코드는 지수 감쇠(`d × min(1, dt×6)`)로 서버 좌표에 '다가갔다'. 그 곡선은 새 좌표가 오는
     순간 가장 빠르고 다음 좌표가 올 때쯤 거의 멈춘다 — 1초 주기로 **빨라졌다 느려지는** 톱니가
     그대로 눈에 보인다(실측: 프레임 간 이동량 표준편차 ÷ 평균 = 0.94).
     고친 규칙은 교과서 그대로다:
       ① 서버 좌표를 **두 개**(prev·next) 들고 있는다.
       ② 그리는 시각을 **한 스텝 뒤로 미룬다**(지연 버퍼) — 다음 좌표가 이미 손에 있는 구간만 그린다.
       ③ 그 두 점 사이를 **등속**으로 지난다. k 는 [0,1] 로 잘라 **외삽하지 않는다**
          (패킷이 늦으면 멈춰 기다린다 — 앞질러 갔다가 되돌아오는 것이 가장 큰 끊김이다).
       ④ 방향은 값이 아니라 **각도를 스무딩**해서 정한다. 왼·오른쪽 뒤집기에는 문턱을 둬
          제자리걸음에 스프라이트가 파닥거리지 않게 한다. */
  /* ★ §16-3 — 두 점 버퍼를 **스냅샷 띠(ring buffer)** 로 바꾼다.
     옛 규칙(prev·next 두 점 + 고정 지연 1000ms)은 지연폭이 스냅샷 간격과 **정확히 같을 때만** 등속이다.
     간격이 흔들리면(서버 setInterval·네트워크·프레임 처짐) 그 차이만큼 매 주기 얼어붙었다 움직이는
     미세 끊김이 남고, 시계가 벽시계보다 늦게 가면(무거운 프레임의 dt 캡) 1초에 한 번 순간이동이 됐다.
     이제 놈마다 ① 최근 좌표 넉 장을 띠로 들고 ② 간격을 EMA 로 재서 ③ 그 1.4배 + 여유만큼 뒤를
     그린다. 그리는 시각을 품는 두 장 사이를 등속으로 지나므로, 간격이 40% 흔들려도 걸음은 고르다.
     외삽은 여전히 없다 — 띠의 끝을 넘어서는 그 자리에 선다. */
  var wildClock = 0;                     // 애니메이션 시계(ms) — rAF 가 없어도 도는 자체 시계
  var GAP_DEFAULT = 600;                 // 아직 간격을 못 잰 놈의 기본값(서버 0.5초 스텝 + 여유)
  var BUF_KEEP = 5;                      // 띠에 남기는 스냅샷 수

  function bufDelay(a) {
    var g = (a && a.gapMs) || GAP_DEFAULT;
    return Math.min(2400, Math.max(160, g * 1.4 + 80));
  }

  /** 그릴 시각 = 시계 − 지연폭. ★ 지연폭은 **한 번에 움직이지 않는다** — 간격을 새로 배울 때마다
      지연폭이 툭 바뀌면 그 순간 화면이 한 발 건너뛴다(실측: 프레임 이동량 스파이크 → 흩어짐 64%).
      늘어날 때는 빠르게(버퍼가 마르기 전에), 줄어들 때는 천천히 미끄러뜨린다. */
  function bufRender(a, clock) {
    var target = bufDelay(a);
    if (a.delay == null) a.delay = target;
    else {
      var el = a.dClock == null ? 0 : clock - a.dClock;
      var diff = target - a.delay;
      var maxStep = diff > 0 ? Math.max(2, el * 0.45) : Math.max(0.5, el * 0.06);
      a.delay += Math.max(-maxStep, Math.min(maxStep, diff));
    }
    a.dClock = clock;
    return clock - a.delay;
  }

  /** 띠에 좌표 한 장을 얹는다 — 간격을 재고, 걸어서 못 갈 거리는 스냅한다.
      ★ 간격은 EMA 가 아니라 **최근 세 장의 최대값**이다. 스트림의 박자가 바뀌면(탭이 멈췄다 돌아옴,
      무거운 프레임 구간) 오래된 박자의 기억이 지연폭을 그르치는데, 최대값은 한 장 만에 따라잡는다. */
  function bufPush(a, x, y, now, snapDist) {
    var last = a.buf[a.buf.length - 1];
    if (last && now <= last.t) now = last.t + 1;   // 미래 스탬프(하차 연출) 뒤에 와도 차례를 지킨다
    if (last) {
      if (last.x === x && last.y === y && now - last.t < 1) return;
      var gap = now - last.t;
      if (gap > 0.5) {
        a.gaps = a.gaps || [];
        a.gaps.push(Math.min(gap, 3000));
        if (a.gaps.length > 3) a.gaps.shift();
        a.gapMs = Math.max.apply(null, a.gaps);
      }
      if (Math.hypot(x - last.x, y - last.y) > snapDist) {
        /* 걸어서는 못 갈 거리 — 같은 놈이 걸어간 것으로 볼 수 없다. 그때만 스냅한다. */
        a.buf = [{ x: x, y: y, t: now }];
        a.x = x; a.y = y;
        return;
      }
    }
    a.buf.push({ x: x, y: y, t: now });
    if (a.buf.length > BUF_KEEP) a.buf.shift();
  }

  /** 띠에서 그릴 자리를 읽는다 — render 시각을 품는 두 장 사이의 등속점. 외삽하지 않는다. */
  function bufAt(a, render) {
    var b = a.buf;
    if (!b.length) return { x: a.x, y: a.y };
    if (render <= b[0].t) return { x: b[0].x, y: b[0].y };
    for (var i = b.length - 1; i >= 0; i--) {
      if (b[i].t <= render) {
        var p = b[i], q = b[i + 1];
        if (!q) return { x: p.x, y: p.y };                  // 띠의 끝 — 멈춰 기다린다
        var k = Math.max(0, Math.min(1, (render - p.t) / Math.max(1, q.t - p.t)));
        return { x: p.x + (q.x - p.x) * k, y: p.y + (q.y - p.y) * k };
      }
    }
    return { x: b[0].x, y: b[0].y };
  }

  function newWild(c, now) {
    return { x: c.x, y: c.y, dir: 1, face: 0, frame: 0, ft: 0, hurt: 0, gapMs: null,
             buf: [{ x: c.x, y: c.y, t: now }] };
  }

  /** 새 좌표 묶음이 왔다 — 각자의 띠에 한 장씩 얹는다 */
  function pushWildSnapshot(list) {
    var now = wildClock;
    for (var i = 0; i < (list || []).length; i++) {
      var c = list[i];
      var a = wild[c.id];
      if (!a) { wild[c.id] = newWild(c, now); continue; }
      bufPush(a, c.x, c.y, now, WILD_SNAP);
    }
    for (var k in wild) {
      if (!Object.prototype.hasOwnProperty.call(wild, k)) continue;
      var alive = false;
      for (var j = 0; j < (list || []).length; j++) if (list[j].id === k) { alive = true; break; }
      if (!alive) delete wild[k];
    }
  }

  function stepWild(dt) {
    wildClock += dt * 1000;
    var list = S.creatureList();
    var seen = {};
    for (var i = 0; i < list.length; i++) {
      var c = list[i];
      seen[c.id] = true;
      var a = wild[c.id];
      if (!a) { wild[c.id] = newWild(c, wildClock); continue; }
      var pos = bufAt(a, bufRender(a, wildClock));
      var mx = pos.x - a.x, my = pos.y - a.y;
      a.x = pos.x; a.y = pos.y;
      var moved = Math.hypot(mx, my);
      if (moved > 0.0015) {
        /* 방향 스무딩 — 각도를 따라가고, 좌우 뒤집기에는 문턱을 둔다 */
        var want = Math.atan2(my, mx);
        var diff = Math.atan2(Math.sin(want - a.face), Math.cos(want - a.face));
        a.face += diff * Math.min(1, dt * 7);
        var cosF = Math.cos(a.face);
        if (cosF > 0.22) a.dir = 1;
        else if (cosF < -0.22) a.dir = -1;
        a.ft += dt;
        if (a.ft > 0.22) { a.ft = 0; a.frame = a.frame ? 0 : 1; }
      }
      if (a.hurt > 0) a.hurt = Math.max(0, a.hurt - dt);
    }
    for (var id in wild) if (Object.prototype.hasOwnProperty.call(wild, id) && !seen[id]) delete wild[id];
  }

  function markWildHurt(id) { if (wild[id]) wild[id].hurt = 0.35; }

  /* ══════════ ★ GDD3 §15-C — 함께 있는 사람들(동료 봇 · 같이 접속한 이)의 걸음 ══════════
     그들의 자리는 1초에 한 번 온다(동료는 서버 저빈도 두뇌가, 사람은 걸음 보고가 그 박자다).
     그대로 그리면 1초마다 툭툭 튄다 — 짐승에게 쓴 §14-3 의 규칙을 그대로 쓴다:
     두 점을 들고, 한 스텝 뒤를 등속으로 지나고, 외삽하지 않는다. */
  var mates = {};
  var MATE_SNAP = 12;

  /* ★ §16-7 — 마차 동반 하차. 오프닝이 도는 동안 동료들은 **마차 안**이라 그리지 않고,
     막이 걷히는 순간 마차 자리에서 한 사람씩(0.5초 간격) 내려 제 자리로 걸어간다.
     서버 좌표는 건드리지 않는다 — 내리는 연출은 순전히 화면의 몫이고,
     띠 보간(stepMates)이 마차→실제 자리 걸음을 알아서 그린다. */
  function crewDisembark(x, y) {
    var list = S.S.avatars || [];
    var mine = S.S.avatarId;
    var k = 0;
    for (var i = 0; i < list.length; i++) {
      var v = list[i];
      if (v.id === mine) continue;
      var t0 = wildClock + 500 + k * 550;
      var walkMs = Math.max(400, Math.hypot(v.x - x, v.y - y) / 3.2 * 1000);
      mates[v.id] = {
        x: x, y: y, dir: 0, frame: 0, ft: 0, gapMs: 900, delay: 200,
        buf: [{ x: x, y: y, t: t0 }, { x: v.x, y: v.y, t: t0 + walkMs }]
      };
      k += 1;
    }
  }

  function stepMates(dt) {
    var list = S.S.avatars || [];
    var mine = S.S.avatarId;
    var opening = GM.opening && GM.opening.busy();
    var seen = {};
    for (var i = 0; i < list.length; i++) {
      var v = list[i];
      if (v.id === mine) continue;                 // 내 몸은 avatar.js 가 쥔다
      if (opening) { seen[v.id] = true; continue; } // ★ §16-7 — 아직 마차 안이다
      seen[v.id] = true;
      var a = mates[v.id];
      if (!a) {
        mates[v.id] = { x: v.x, y: v.y, dir: 0, frame: 0, ft: 0, gapMs: null,
                        buf: [{ x: v.x, y: v.y, t: wildClock }] };
        continue;
      }
      /* 새 좌표가 왔으면(값이 바뀌었으면) 띠에 얹는다 — 짐승과 같은 §16-3 규칙 */
      var last = a.buf[a.buf.length - 1];
      if (!last || last.x !== v.x || last.y !== v.y) bufPush(a, v.x, v.y, wildClock, MATE_SNAP);
      var pos = bufAt(a, bufRender(a, wildClock));
      var mx = pos.x - a.x, my = pos.y - a.y;
      a.x = pos.x; a.y = pos.y;
      if (Math.hypot(mx, my) > 0.0015) {
        a.dir = Math.abs(mx) > Math.abs(my) ? (mx > 0 ? 2 : 1) : (my > 0 ? 0 : 3);
        a.ft += dt;
        if (a.ft > 0.18) { a.ft = 0; a.frame = a.frame ? 0 : 1; }
      } else a.frame = 0;
    }
    for (var id in mates) if (Object.prototype.hasOwnProperty.call(mates, id) && !seen[id]) delete mates[id];
  }

  function drawWild() {
    var list = S.creatureList();
    if (!list.length) return;
    var t = GM.camera.cam.tile;
    for (var i = 0; i < list.length; i++) {
      var c = list[i];
      var a = wild[c.id] || { x: c.x, y: c.y, frame: 0, dir: 1, hurt: 0 };
      if (!GM.camera.onScreen(a.x, a.y, t * 2)) continue;
      if (S.fogAt(Math.round(a.x), Math.round(a.y)) < 2) continue;   // 지금 눈에 보이는 것만
      var p = GM.camera.worldToScreen(a.x - 0.5, a.y - 0.5);
      var img = GM.atlas.wild(c.sp, a.frame, { hurt: a.hurt > 0 });
      ctx.save();
      if (a.dir < 0) {
        ctx.translate(Math.round(p.x) + t, Math.round(p.y));
        ctx.scale(-1, 1);
        try { ctx.drawImage(img, 0, 0, Math.ceil(t), Math.ceil(t)); } catch (e) {}
      } else {
        try { ctx.drawImage(img, Math.round(p.x), Math.round(p.y), Math.ceil(t), Math.ceil(t)); } catch (e2) {}
      }
      ctx.restore();
      /* 성이 난 놈은 발밑이 붉다 — 쫓기고 있다는 것을 한눈에 */
      if (c.kind === 'predator' && c.state === 'chase') {
        ctx.save();
        ctx.globalAlpha = 0.5 + 0.3 * Math.sin(animT / 140);
        ctx.strokeStyle = '#bc4749';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.ellipse(p.x + t / 2, p.y + t * 0.92, t * 0.34, t * 0.16, 0, 0, Math.PI * 2);
        ctx.stroke();
        ctx.restore();
      }
      if (c.hp < c.maxHp && t >= 18) {
        var w = t * 0.7;
        ctx.fillStyle = 'rgba(20,14,8,.65)';
        ctx.fillRect(p.x + (t - w) / 2, p.y - 5, w, 3);
        ctx.fillStyle = c.kind === 'predator' ? '#bc4749' : '#8dbb6d';
        ctx.fillRect(p.x + (t - w) / 2, p.y - 5, w * Math.max(0, c.hp / c.maxHp), 3);
      }
    }
  }

  /* ══════════ 건물 · 공사 · 도읍 ══════════ */
  var doneBounce = {};      // structureId → 완공 연출 시작 시각
  var structSort = { sig: '', list: [] };

  function bounceStructure(id) { doneBounce[id] = animT; }

  /** y 순으로 정렬된 건물 목록 — 60fps 예산을 위해 목록이 바뀔 때만 다시 정렬한다 */
  function sortedStructures() {
    var src = S.structures();
    var sig = src.length + ':' + (src.length ? src[0].id + ':' + src[src.length - 1].id : '');
    if (structSort.sig !== sig) {
      structSort.sig = sig;
      structSort.list = src.slice().sort(function (a, b) { return (a.y || 0) - (b.y || 0); });
    }
    return structSort.list;
  }

  function drawStructures() {
    var cam = GM.camera.cam, t = cam.tile;
    var m = S.S.map;
    var sel = S.S.selection || {};
    if (m) {
      /* ★ §12-2 — 도읍 자리에는 이제 4×4 본부가 선다. 옛 '도읍 그림'은 본부가 없을 때의 대비책이다. */
      if (!S.hq()) {
        (m.towns || []).forEach(function (tw) {
          if (!tw.isPlayer) return;
          if (!GM.camera.onScreen(tw.x, tw.y, t * 2)) return;
          var p = GM.camera.worldToScreen(tw.x - 1, tw.y - 1);
          try { ctx.drawImage(GM.atlas.town(true), Math.round(p.x), Math.round(p.y), Math.ceil(t * 2), Math.ceil(t * 2)); } catch (e) {}
        });
      }
      /* ★ §12-6 — 무역이 열리기 전에는 상단이 없다 (서버도 빈 목록을 준다. 화면도 한 번 더 막는다) */
      (S.featOn('trade') ? (m.caravans || []) : []).forEach(function (cvn, i) {
        var ph = ((animT / 9000) + i * 0.31) % 1;
        var f = ph > 0.5 ? (1 - ph) * 2 : ph * 2;
        var x = cvn.from.x + (cvn.to.x - cvn.from.x) * f;
        var y = cvn.from.y + (cvn.to.y - cvn.from.y) * f;
        if (S.fogAt(Math.round(x), Math.round(y)) < 2) return;
        if (!GM.camera.onScreen(x, y, t)) return;
        var p2 = GM.camera.worldToScreen(x - 0.5, y - 0.4);
        try { ctx.drawImage(GM.atlas.caravan(), Math.round(p2.x), Math.round(p2.y), Math.ceil(t), Math.ceil(t * 0.75)); } catch (e) {}
      });
    }

    /* 뒤에 있는 것부터 그린다 — y 순 정렬 (목록이 바뀔 때만 다시 정렬) */
    var list = sortedStructures();
    list.forEach(function (b) {
      if (b.x == null) return;
      /* ★ §12-1 — 풋프린트 기준 렌더. 1×1 이면 옛 값과 정확히 같다(1.7칸). */
      var f = S.footprintOfThing(b);
      var c = S.centerOfThing(b);
      if (!GM.camera.onScreen(c.x, c.y, t * (Math.max(f.w, f.h) + 2))) return;
      var scale = 1;
      var bd = doneBounce[b.id];
      if (bd !== undefined) {
        var age = (animT - bd) / 1000;
        if (age > 0.75) delete doneBounce[b.id];
        else scale = 1 + Math.sin(Math.min(1, age / 0.75) * Math.PI) * 0.22 * (1 - age / 0.75);
      }
      var w = t * (f.w + 0.7) * scale, h = t * (f.h + 0.7) * scale;
      var baseY = c.y + (f.h - 1) / 2 + 0.55;
      var p = GM.camera.worldToScreen(c.x - (f.w + 0.7) / 2 + 0.1, baseY - (f.h + 0.7));
      /* 본부 둘레의 광장 — 티어에 비례해 넓어진다 (§12-2) */
      if (b.hq) drawPlaza(c, t);
      /* 그림자 */
      ctx.save();
      ctx.globalAlpha = 0.24;
      ctx.fillStyle = '#000';
      ctx.beginPath();
      try { ctx.ellipse(p.x + w / 2, p.y + h - t * 0.18, w * 0.34, w * 0.13, 0, 0, Math.PI * 2); } catch (e) {}
      ctx.fill();
      ctx.restore();
      ctx.save();
      /* 이전·철거 중이면 반투명 — 효과가 멎었다는 표시 (§12-12) */
      if (b.inactive) ctx.globalAlpha = 0.55;
      try {
        var sprite = b.hq ? GM.atlas.hall(S.tierNo(), { ruined: b.ruined })
                          : GM.atlas.building(b.key, b.tier, { ruined: b.ruined });
        ctx.drawImage(sprite, Math.round(p.x), Math.round(p.y), Math.ceil(w), Math.ceil(h));
      } catch (e2) {}
      ctx.restore();
      /* 개축 중 — 황금 반짝 */
      if (b.upgrading) {
        ctx.save();
        ctx.globalAlpha = 0.28 + 0.24 * Math.sin(animT / 200);
        ctx.fillStyle = '#f6cf7a';
        ctx.fillRect(p.x, p.y, w, h);
        ctx.restore();
      }
      /* 내구도 — 상했을 때만 */
      var cond = b.condition === undefined ? 1 : b.condition;
      if (cond < 0.995 && t >= 18) {
        var bw = t * 1.1;
        var bx = p.x + (w - bw) / 2, by = p.y + h - t * 0.1;
        ctx.fillStyle = 'rgba(20,14,8,.7)';
        ctx.fillRect(bx, by, bw, 4);
        ctx.fillStyle = cond < 0.35 ? '#bc4749' : (cond < 0.7 ? '#e8a33d' : '#8dbb6d');
        ctx.fillRect(bx, by, bw * cond, 4);
      }
      if (b.ruined) label('부서짐', c.x, c.y - f.h / 2 - 0.8, '#ff9d99');
      else if (b.work) label(b.work.mode === 'demolish' ? '허무는 중' : '옮기는 중',
        c.x, c.y - f.h / 2 - 0.8, '#f0a09c');
      else if (t >= 26) label(b.name + (b.tier > 1 && !b.hq ? ' ' + b.tier : ''),
        c.x, c.y + f.h / 2 + 0.3, '#f4e4bc');
      if (sel.structureId === b.id) footRing(c, f, '#e8a33d');
    });

    S.sites().forEach(function (c) {
      if (c.x == null) return;
      var sf = S.footprintOfThing(c);
      var sc = S.centerOfThing(c);
      if (!GM.camera.onScreen(sc.x, sc.y, t * (Math.max(sf.w, sf.h) + 2))) return;
      var sw = t * (sf.w + 0.6), shh = t * (sf.h + 0.6);
      var sbase = sc.y + (sf.h - 1) / 2 + 0.5;
      var p = GM.camera.worldToScreen(sc.x - (sf.w + 0.6) / 2, sbase - (sf.h + 0.6));
      try { ctx.drawImage(GM.atlas.site(c.progress), Math.round(p.x), Math.round(p.y), Math.ceil(sw), Math.ceil(shh)); } catch (e) {}
      var bx = GM.camera.worldToScreen(sc.x - (sf.w + 0.6) / 2, sbase + 0.12);
      ctx.fillStyle = 'rgba(20,14,8,.72)';
      ctx.fillRect(bx.x, bx.y, sw, 6);
      /* 철거·이전은 붉은 띠 — 짓는 일과 헐는 일을 색으로 가른다 (§12-12) */
      ctx.fillStyle = (c.mode === 'demolish' || c.mode === 'relocate') ? '#bc4749' : '#e8a33d';
      ctx.fillRect(bx.x, bx.y, sw * U.clamp(c.progress || 0, 0, 1), 6);
      if (t >= 22) label(c.name + ' ' + (c.modeName || '공사'), sc.x, sc.y + sf.h / 2 + 0.9, '#f6cf7a');
      /* 이전이면 갈 자리를 점선으로 미리 보여 준다 */
      if (c.mode === 'relocate' && c.toX != null) ghostRect(c.toX, c.toY, sf, '#8dfa8d');
      if (sel.siteId === c.id) footRing(sc, sf, '#e8a33d');
    });
  }

  /** 풋프린트 사각형을 두르는 선택 테두리 */
  function footRing(c, f, color) {
    var t = GM.camera.cam.tile;
    var p = GM.camera.worldToScreen(c.x - f.w / 2, c.y - f.h / 2);
    ctx.save();
    ctx.strokeStyle = color;
    ctx.lineWidth = 2;
    ctx.setLineDash([5, 4]);
    ctx.strokeRect(Math.round(p.x), Math.round(p.y), Math.ceil(f.w * t), Math.ceil(f.h * t));
    ctx.restore();
  }

  /** 좌상단 앵커 기준 점선 사각형 (이전 목적지 미리보기) */
  function ghostRect(ax, ay, f, color) {
    var t = GM.camera.cam.tile;
    var p = GM.camera.worldToScreen(ax - 0.5, ay - 0.5);
    ctx.save();
    ctx.globalAlpha = 0.5 + 0.3 * Math.sin(animT / 260);
    ctx.strokeStyle = color;
    ctx.lineWidth = 2;
    ctx.setLineDash([6, 4]);
    ctx.strokeRect(Math.round(p.x), Math.round(p.y), Math.ceil(f.w * t), Math.ceil(f.h * t));
    ctx.restore();
  }

  /** ★ §12-2 본부 광장 — 티어에 비례해 넓어지는 장식 바닥 */
  function drawPlaza(c, t) {
    var r = (3.2 + S.tierNo() * 0.9) * t;
    var p = GM.camera.worldToScreen(c.x, c.y);
    ctx.save();
    var g;
    try {
      g = ctx.createRadialGradient(p.x, p.y, r * 0.2, p.x, p.y, r);
      g.addColorStop(0, 'rgba(146,120,86,.34)');
      g.addColorStop(0.75, 'rgba(120,98,70,.18)');
      g.addColorStop(1, 'rgba(120,98,70,0)');
    } catch (e) { g = null; }
    if (g) {
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(p.x, p.y, r, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();
  }

  /* ══════════ 적 캠프 ══════════ */
  function drawCamps() {
    var t = GM.camera.cam.tile;
    S.camps().forEach(function (c) {
      if (c.x == null) return;
      if (!GM.camera.onScreen(c.x, c.y, t * 3)) { edgeMarker(c); return; }
      var p = GM.camera.worldToScreen(c.x - 1, c.y - 1);
      try { ctx.drawImage(GM.atlas.camp(c.type), Math.round(p.x), Math.round(p.y), Math.ceil(t * 2), Math.ceil(t * 2)); } catch (e) {}
      label(c.name + (c.sizeHint ? ' · ' + c.sizeHint : ' · 규모 모름'), c.x, c.y - 1.3, '#f0a09c');
      if (!c.scouted) {
        ctx.save();
        ctx.globalAlpha = 0.35 + 0.35 * Math.sin(animT / 320);
        ctx.strokeStyle = '#bc4749';
        ctx.lineWidth = 2;
        ctx.setLineDash([5, 5]);
        ctx.beginPath();
        ctx.arc(p.x + t, p.y + t, t * 1.8, 0, Math.PI * 2);
        ctx.stroke();
        ctx.restore();
      }
    });
  }

  function edgeMarker(c) {
    var p = GM.camera.worldToScreen(c.x, c.y);
    var cxp = W / 2, cyp = H / 2;
    var dx = p.x - cxp, dy = p.y - cyp;
    if (!dx && !dy) return;
    var m = 34;
    var sc = Math.min((W / 2 - m) / Math.max(1, Math.abs(dx)), (H / 2 - m) / Math.max(1, Math.abs(dy)));
    var ex = cxp + dx * sc, ey = cyp + dy * sc;
    ctx.save();
    ctx.translate(ex, ey);
    ctx.rotate(Math.atan2(dy, dx));
    ctx.globalAlpha = 0.5 + 0.4 * Math.sin(animT / 300);
    ctx.fillStyle = '#bc4749';
    ctx.beginPath();
    ctx.moveTo(12, 0); ctx.lineTo(-9, -8); ctx.lineTo(-9, 8);
    ctx.closePath(); ctx.fill();
    ctx.restore();
  }

  /* ══════════ 주민 ══════════
     ★ GDD3 §12-11 — 텔레포트 버그의 정공 해법.
       옛 코드는 "클라 보간 위치가 서버 좌표에서 10칸 넘게 벌어지면 서버 좌표로 되돌린다"는
       고무줄을 달고 있었다. 그런데 서버의 주민 좌표(u.x,u.y)는 **일 틱(기본 10분)에 한 번**
       moveTilesPerTick 만큼만 나아간다 — 클라는 초당 2.6칸으로 걸어 15칸 떨어진 나무에 몇 초 만에
       닿는다. 그 순간 벌어진 거리가 10을 넘고, 고무줄이 주민을 **출발 자리로 되돌린다.** 그리고
       다시 걷고, 다시 되돌아가고… 이것이 "이동 중 출발 위치로 반복 순간이동"의 정체다.

       고친 원칙(§12-11 그대로):
         · 직업·대상이 그대로면 **위치의 주인은 클라**다. 서버 좌표는 쳐다보지 않는다.
         · 서버가 주는 (destX,destY) 는 위치가 아니라 **목표점**이다.
         · 스냅은 **대상이 바뀐 순간에만**, 그것도 정말 멀 때(SNAP_TILES)만 한다.
       그래서 서버가 뭘 방송하든 걷던 사람이 뒤로 튀는 일이 없다.

     ★ GDD3 §12-9 — 그 위에 노동 상태 머신을 얹었다(순수 연출):
       이동 → 작업(스윙·파편·노드 흔들림) → 들짐 → 저장 궤짝/저장고로 운반 → 하역 → 복귀 */
  var SNAP_TILES = 26;          // 이만큼 멀면 '같은 사람이 걸어간 것'으로 볼 수 없다 → 그때만 스냅
  var WALK_SPEED = 2.6;
  var CARRY_JOBS = { farm: 'grain', lumber: 'wood', quarry: 'stone', mine: 'ironOre' };

  function unitSig(v) {
    return (v.job || '') + '|' + (v.targetId || '') + '|' + (v.destX == null ? v.x : v.destX)
      + ',' + (v.destY == null ? v.y : v.destY);
  }

  /** 짐을 부릴 곳 — 저장 궤짝·저장고·곡창이 있으면 가장 가까운 곳, 없으면 본부 */
  function dropSpot(from) {
    var best = null, bd = 1e9;
    var list = S.structures();
    for (var i = 0; i < list.length; i++) {
      var b = list[i];
      if (b.x == null) continue;
      if (b.key !== 'storage_crate' && b.key !== 'storage' && b.key !== 'granary' && !b.hq) continue;
      var c = S.centerOfThing(b);
      var d = Math.hypot(c.x - from.x, c.y - from.y) + (b.hq ? 6 : 0);   // 본부는 마지막 수단
      if (d < bd) { bd = d; best = { x: c.x, y: c.y, id: b.id }; }
    }
    if (best) return best;
    var t = S.myTown();
    return t ? { x: t.x, y: t.y, id: null } : null;
  }

  function faceTo(a, dx, dy) {
    a.dir = Math.abs(dx) > Math.abs(dy) ? (dx > 0 ? 2 : 1) : (dy > 0 ? 0 : 3);
  }

  /** 목표점으로 한 걸음. 닿았으면 true */
  function walkStep(a, tx, ty, dt, speed) {
    var dx = tx - a.x, dy = ty - a.y;
    var d = Math.hypot(dx, dy);
    if (d <= 0.08) { a.frame = 0; return true; }
    var mv = Math.min(d, (speed || WALK_SPEED) * dt);
    a.x += dx / d * mv; a.y += dy / d * mv;
    faceTo(a, dx, dy);
    a.ft += dt;
    if (a.ft > 0.22) { a.ft = 0; a.frame = a.frame ? 0 : 1; }
    return false;
  }

  /**
   * ★ §12-9 노동 루프 — ★ GDD3 §14-1 로 **순수 연출**이 되었다.
   *
   * 옛 규칙(§13-A-3)은 화면이 짐을 시간만큼 쌓아 두었다가 하역하는 순간 숫자를 띄웠다.
   * 실측해 보니 그 순간이 오기까지 **154초**였고(자루 하나 = 하루길이÷4 = 150초 + 걸어가는 시간),
   * 국고는 그동안 한 톨도 안 움직였다(일 틱 600초). 그것이 "일해도 안 늘고 플로팅도 안 뜬다"의 정체다.
   *
   * 이제 수치는 **서버가 사이클마다 곧바로** 넣고 residentWork 로 알려 준다(creditFloat).
   * 여기 남은 것은 그림뿐이다: 휘두르고, 지고, 날라 부리고, 돌아온다. 자루는 **시간으로만** 찬다
   * (deliveriesPerDay 는 이제 왕복 빈도 다이얼일 뿐 크레딧과 무관하다).
   */
  function stepWork(v, a, dt) {
    var res = CARRY_JOBS[v.job];
    var node = v.targetId ? S.nodeById(v.targetId) : null;
    if (!res || !node) { a.phase = 'idle'; a.carry = 0; return false; }
    a.home = a.home || { x: node.x, y: node.y };
    a.home.x = node.x; a.home.y = node.y;

    var wk = S.villagerWorkCfg();
    var working = !!(v.yield && v.yield.resource === res && v.yield.perDay > 0);
    /* 왕복 한 번에 걸리는 시간 — 하루를 deliveriesPerDay 로 나눈 것(순수 연출 박자) */
    var haulEvery = S.dayRealSeconds() / Math.max(1, wk.deliveriesPerDay);

    if (a.phase === 'work') {
      a.swingT = (a.swingT || 0) + dt;
      a.pose = Math.max(0, 1 - (a.swingT % wk.swingSeconds) / (wk.swingSeconds * 0.47));
      faceTo(a, node.x - a.x, node.y - a.y);
      if (a.swingT - (a.lastHit || 0) >= wk.swingSeconds) {
        a.lastHit = a.swingT;
        if (GM.fx) {
          GM.fx.shakeNode(node.id, 0.45);
          GM.fx.debris(node.x, node.y, S.nodeMeta(node.type).color, 3, 0.6);
        }
      }
      /* 일하지 않는 사람(고갈된 노드 등)은 나르지 않는다 — 헛걸음을 보이지 않는다 */
      if (working && a.swingT >= haulEvery) {
        a.carry = 1; a.phase = 'haul'; a.drop = dropSpot(a); a.swingT = 0; a.pose = 0;
      }
      return true;
    }
    if (a.phase === 'haul') {
      if (!a.drop) { a.phase = 'work'; return true; }
      if (walkStep(a, a.drop.x, a.drop.y, dt, WALK_SPEED * 0.86)) { a.phase = 'unload'; a.unloadT = 0; }
      return true;
    }
    if (a.phase === 'unload') {
      a.unloadT = (a.unloadT || 0) + dt;
      if (a.unloadT > 0.55) {
        /* 부리는 그림만 남았다 — 숫자는 서버가 사이클마다 이미 띄웠다(§14-1) */
        if (GM.fx) GM.fx.dust(a.x, a.y, 4, '#c8a874');
        a.carry = 0;
        a.phase = 'return';
      }
      return true;
    }
    if (a.phase === 'return') {
      if (walkStep(a, a.home.x, a.home.y, dt, WALK_SPEED)) { a.phase = 'work'; a.swingT = 0; a.lastHit = 0; }
      return true;
    }
    return false;
  }

  /**
   * ★ GDD3 §14-1 — 서버가 방금 곳간에 넣은 한 사이클 몫을 그 사람 자리에 띄운다.
   *   연출 좌표(units[id])가 있으면 그 자리에, 없으면 서버가 준 좌표에 띄운다.
   *   숫자 서식은 플레이어 스윙과 같다("+0.11 목재") — 값이 작을수록 소수 자리를 늘려 0 이 안 뜬다.
   */
  function creditFloat(c) {
    if (!c || !GM.fx) return false;
    var a = units[c.id];
    var x = a ? a.x : c.x;
    var y = a ? a.y : c.y;
    if (!GM.camera.onScreen(x, y, GM.camera.cam.tile * 3)) return false;
    var meta = S.resourceMeta(c.resource) || {};
    var n = Number(c.amount) || 0;
    if (n <= 0) return false;
    var digits = n >= 10 ? 0 : (n >= 1 ? 1 : 2);
    GM.fx.floatText(x, y - 0.9, '+' + U.fmt(n, digits) + ' ' + (meta.name || c.resource),
      meta.color || '#f6e6a8', 12);
    GM.fx.resourcePop(x, y - 0.4, c.resource, '', meta.color);
    return true;
  }

  /**
   * ★ GDD3 §15-A-2 — 터렛이 잡은 자리.
   *   드롭은 서버가 이미 국고에 넣었다(저장 상한도 서버가 지켰다). 여기서는 **그 자리에** 값을 띄운다.
   *   한 마리가 여러 자원을 떨구면 줄을 조금씩 어긋나게 쌓아 서로 가리지 않게 한다.
   */
  function turretKillFloat(k) {
    if (!k || !GM.fx) return false;
    var x = Number(k.x) || 0, y = Number(k.y) || 0;
    if (!GM.camera.onScreen(x, y, GM.camera.cam.tile * 3)) return false;
    GM.fx.debris(x, y, '#bc4749', 7, 0.9);
    GM.fx.ring(x, y, '#f6cf7a', 0.2, 1.3, 0.5);
    var keys = Object.keys(k.gained || {});
    if (!keys.length) {
      GM.fx.floatText(x, y - 0.9, (k.name || '') + ' 처치', '#dcd0b4', 11);
      return true;
    }
    keys.forEach(function (r, i) {
      var meta = S.resourceMeta(r) || {};
      var n = Number(k.gained[r]) || 0;
      if (n <= 0) return;
      var digits = n >= 10 ? 0 : (n >= 1 ? 1 : 2);
      GM.fx.floatText(x, y - 0.9 - i * 0.55, '+' + U.fmt(n, digits) + ' ' + (meta.name || r),
        meta.color || '#f6e6a8', 12);
      GM.fx.resourcePop(x, y - 0.4, r, '', meta.color);
    });
    return true;
  }

  function stepUnits(dt) {
    var list = S.residents();
    var seen = {};
    for (var i = 0; i < list.length; i++) {
      var v = list[i];
      seen[v.id] = 1;
      var a = units[v.id];
      var sig = unitSig(v);
      if (!a) {
        /* 처음 본 사람 — 서버가 아는 자리에서 시작한다 */
        a = units[v.id] = { x: v.x, y: v.y, dir: 0, frame: 0, ft: 0, sig: sig,
                            phase: 'travel', carry: 0, pose: 0 };
      }
      if (a.sig !== sig) {
        /* ★ 대상이 바뀌었다 — 이때만 스냅을 따진다. 그것도 '걸어서는 못 갈 거리'일 때만. */
        a.sig = sig;
        a.phase = 'travel';
        a.carry = 0; a.pose = 0; a.swingT = 0; a.lastHit = 0; a.drop = null; a.home = null;
        if (Math.hypot(a.x - v.x, a.y - v.y) > SNAP_TILES) { a.x = v.x; a.y = v.y; }
      }

      /* 노동 루프가 돌고 있으면 이동은 그 안에서 한다 */
      if (a.phase !== 'travel' && stepWork(v, a, dt)) continue;

      var tx = v.destX == null ? v.x : v.destX;
      var ty = v.destY == null ? v.y : v.destY;
      if (walkStep(a, tx, ty, dt)) {
        /* 일터에 닿았다 — 노동 연출로 넘어간다 */
        if (a.phase === 'travel' && CARRY_JOBS[v.job] && v.targetId && S.nodeById(v.targetId)) {
          a.phase = 'work'; a.swingT = 0; a.lastHit = 0;
        } else {
          a.phase = 'idle';
        }
      }
    }
    for (var id in units) if (!seen[id]) delete units[id];

    /* ★ §13-A-4 도착 표시 — 걷는 것은 진짜 주민이고, 여기서는 **이름표만** 세어 지운다 */
    for (var k = walkIns.length - 1; k >= 0; k--) {
      walkIns[k].t += dt;
      if (walkIns[k].t > 12 || !units[walkIns[k].id]) walkIns.splice(k, 1);
    }
  }

  /**
   * ★ GDD3 §13-A-4 — 새로 온 사람을 **표시**한다. 몸을 하나 더 만들지 않는다.
   *
   * 고친 버그: 한 명이 왔는데 두 명이 걸어 들어왔다.
   *   서버는 처음부터 주민을 **영토 밖에 세우고** destX,destY 를 마을로 잡아 준다 —
   *   즉 진짜 주민이 이미 스스로 걸어 들어온다. 그런데 화면은 residentArrived 를 받고
   *   똑같은 자리에서 똑같은 외형·이름의 **연출용 유령**을 하나 더 걸었다.
   *   둘은 속도(2.4 vs 2.6)와 도착점이 살짝 달라 나란히 걷는 두 사람으로 보였다.
   * 이제 유령은 없다. 진짜 주민 머리 위에 이름표를 잠시 띄울 뿐이다.
   */
  function markArrival(id, name) {
    if (!id) return;
    for (var i = 0; i < walkIns.length; i++) if (walkIns[i].id === id) return;
    walkIns.push({ id: id, name: name || '새 사람', t: 0 });
    if (walkIns.length > 6) walkIns.shift();
  }

  function drawResidents() {
    var cam = GM.camera.cam, t = cam.tile;
    var sel = (S.S.selection && S.S.selection.residents) || [];
    var list = S.residents();
    for (var i = 0; i < list.length; i++) {
      var v = list[i];
      var a = units[v.id];
      if (!a) continue;
      if (!GM.camera.onScreen(a.x, a.y, t * 2)) continue;
      var w = t * 0.72, h = t * 0.92;
      var p = GM.camera.worldToScreen(a.x - 0.36, a.y - 0.8);
      if (sel.indexOf(v.id) >= 0) {
        ctx.save();
        ctx.strokeStyle = '#8dfa8d';
        ctx.lineWidth = 2;
        ctx.beginPath();
        try { ctx.ellipse(p.x + w / 2, p.y + h, w * 0.55, w * 0.3, 0, 0, Math.PI * 2); } catch (e) {}
        ctx.stroke();
        ctx.restore();
      }
      ctx.save();
      ctx.globalAlpha = 0.22;
      ctx.fillStyle = '#000';
      ctx.beginPath();
      try { ctx.ellipse(p.x + w / 2, p.y + h - 1, w * 0.35, w * 0.15, 0, 0, Math.PI * 2); } catch (e2) {}
      ctx.fill();
      ctx.restore();
      var sp = v.appearance
        ? GM.atlas.avatar(v.appearance, a.dir, a.frame, { crown: false })
        : GM.atlas.folk(v.job, a.dir, a.frame);
      /* ★ §12-9 — 작업 중이면 몸이 앞으로 기울고(스윙), 짐을 지면 살짝 눌린다 */
      var lean = (a.pose || 0) * 0.28;
      if (lean > 0.01) {
        ctx.save();
        ctx.translate(p.x + w / 2, p.y + h);
        ctx.rotate((a.dir === 1 ? lean : -lean) * 0.5);
        ctx.translate(-(p.x + w / 2), -(p.y + h));
      }
      try { ctx.drawImage(sp, Math.round(p.x), Math.round(p.y), Math.ceil(w), Math.ceil(h)); } catch (e3) {}
      if (lean > 0.01) ctx.restore();
      /* 들짐 — 머리 위 자루 */
      if ((a.carry || 0) > 0 && (a.phase === 'haul' || a.phase === 'unload')) {
        ctx.save();
        ctx.fillStyle = '#8a5e33';
        ctx.fillRect(Math.round(p.x + w * 0.18), Math.round(p.y - t * 0.22), Math.ceil(w * 0.64), Math.ceil(t * 0.24));
        ctx.fillStyle = '#c8a874';
        ctx.fillRect(Math.round(p.x + w * 0.18), Math.round(p.y - t * 0.22), Math.ceil(w * 0.64), Math.max(1, Math.ceil(t * 0.06)));
        ctx.restore();
      }
      if (v.militia) {
        ctx.fillStyle = '#bc4749';
        ctx.fillRect(p.x + w - 3, p.y - 2, 4, 4);
      }
      if (t >= 26 && v.job && v.job !== 'idle') {
        var im = GM.icons.canvas(S.jobMeta(v.job).icon, 11);
        if (im) { try { ctx.drawImage(im, Math.round(p.x + w * 0.15), Math.round(p.y - 12), 11, 11); } catch (e4) {} }
      }
    }

    /* ★ §13-A-4 — 막 도착한 사람의 이름표. 몸은 위에서 이미 한 번 그렸다(하나뿐이다). */
    for (var k = 0; k < walkIns.length; k++) {
      var wi = walkIns[k];
      var wa = units[wi.id];
      if (!wa || !GM.camera.onScreen(wa.x, wa.y, t * 2)) continue;
      label(wi.name, wa.x, wa.y - 1.15, '#f6e6a8');
    }
  }

  /* ══════════ 아바타 ══════════ */
  /* ★ GDD3 §15-C — 동료가 지금 무엇을 하고 있는가. 이름표 밑에 한 낱말로 적는다:
     서 있기만 하는 사람과 일하러 가는 사람이 눈으로 갈려야 「살아 있다」가 된다. */
  var CREW_DOING = {
    node: '캐는 중', site: '짓는 중', creature: '싸우는 중', enemy: '싸우는 중',
    haul: '나르는 중', rest: '쉬는 중', flee: '물러나는 중', down: '쓰러짐', idle: ''
  };

  function drawAvatars() {
    var t = GM.camera.cam.tile;
    var mine = S.S.avatarId;
    var opening = GM.opening && GM.opening.busy();
    (S.S.avatars || []).forEach(function (a) {
      if (a.id === mine) return;
      if (opening) return;                         // ★ §16-7 — 아직 마차 안이다(하차 연출로 내린다)
      var m = mates[a.id] || { x: a.x, y: a.y, dir: 0, frame: 0 };
      if (!GM.camera.onScreen(m.x, m.y, t * 2)) return;
      /* 이름표 색이 사람과 동료를 가른다: 같이 온 사람은 푸른빛, 동료는 저마다의 빛깔이다. */
      var color = a.bot ? (a.color || '#8fe3b4') : '#a8c8ff';
      drawLord(m.x, m.y, a.appearance, m.dir, m.frame, a.name || '개척자', color, a.id, 0, null, a.down);
      if (!a.bot) return;
      var doing = a.down ? CREW_DOING.down : (CREW_DOING[a.state] || '');
      var sub = a.roleName ? (a.roleName + (doing ? ' · ' + doing : '')) : doing;
      if (sub) label(sub, m.x, m.y - 0.42, 'rgba(240,235,220,.86)');
    });
    var me = GM.avatar && GM.avatar.pos();
    // ★ §12-7 — 마차가 굴러오는 동안 개척자는 아직 마차 안에 있다. 내리는 순간 나타난다.
    if (me && !(GM.avatar.isHidden && GM.avatar.isHidden())) {
      var sw = GM.swing ? GM.swing.pose() : { phase: 0, tool: null };
      drawLord(me.x, me.y, S.S.you.appearance, me.dir, me.frame, '그대', '#f6cf7a', mine,
        sw.phase, sw.tool, S.downed());
    }
  }

  /** ★ §12-5 — 우클릭 이동 마커. 목적지에 링이 남아 "어디로 가는지"가 보인다. */
  function drawMoveMarker() {
    if (!GM.avatar || !GM.avatar.destPos) return;
    var d = GM.avatar.destPos();
    if (!d) return;
    var p = GM.camera.worldToScreen(d.x, d.y);
    var t = GM.camera.cam.tile;
    var k = (animT / 700) % 1;
    ctx.save();
    ctx.strokeStyle = '#8dfa8d';
    ctx.lineWidth = 2;
    ctx.globalAlpha = 0.85 - k * 0.5;
    ctx.beginPath();
    ctx.arc(p.x, p.y, t * (0.28 + k * 0.34), 0, Math.PI * 2);
    ctx.stroke();
    ctx.globalAlpha = 0.9;
    ctx.beginPath();
    ctx.arc(p.x, p.y, t * 0.14, 0, Math.PI * 2);
    ctx.stroke();
    ctx.restore();
  }

  function drawLord(x, y, app, dir, frame, name, nameColor, avatarId, swingPhase, tool, down) {
    var t = GM.camera.cam.tile;
    var p = GM.camera.worldToScreen(x - 0.42, y - 1.05);
    var w = t * 0.88, h = t * 1.14;
    ctx.save();
    ctx.globalAlpha = 0.28;
    ctx.fillStyle = '#000';
    ctx.beginPath();
    try { ctx.ellipse(p.x + w / 2, p.y + h - 1, w * 0.4, w * 0.18, 0, 0, Math.PI * 2); } catch (e) {}
    ctx.fill();
    ctx.restore();
    ctx.save();
    if (down) {
      ctx.translate(p.x + w / 2, p.y + h);
      ctx.rotate(-Math.PI / 2.2);
      ctx.globalAlpha = 0.75;
      try { ctx.drawImage(GM.atlas.avatar(app, dir, 0), 0, -w / 2, Math.ceil(w), Math.ceil(h)); } catch (e1) {}
      ctx.restore();
      label(name + ' — 쓰러짐', x, y - 1.35, '#ff9d99');
      return;
    }
    try {
      /* ★ GDD3 §13-D-3 — 내 아바타에는 벼린 것이 그대로 실린다(동료의 장비는 서로 보이지 않는다) */
      var mine = GM.avatar && avatarId === (S.you() && S.you().avatarId);
      var gear = mine && GM.avatar.gear ? GM.avatar.gear() : null;
      ctx.drawImage(GM.atlas.avatar(app, dir, frame, { swing: swingPhase, tool: tool, gear: gear }),
        Math.round(p.x), Math.round(p.y), Math.ceil(w), Math.ceil(h));
    } catch (e2) {}
    ctx.restore();
    if (name && t >= 16) label(name, x, y - 1.35, nameColor || '#f4e4bc');
    var bub = GM.social && avatarId ? GM.social.bubbleFor(avatarId) : null;
    if (bub) label(bub, x, y - 2.15, '#fff6dc');
  }

  /** 스윙 쿨타임 링 — 내 발밑에 남은 시간을 그린다 */
  function drawCooldownRing() {
    if (!GM.swing) return;
    var c = GM.swing.cooldown();
    var me = GM.avatar && GM.avatar.pos();
    if (!me || c.ratio >= 1) return;
    var t = GM.camera.cam.tile;
    var p = GM.camera.worldToScreen(me.x, me.y);
    ctx.save();
    ctx.lineWidth = Math.max(2.5, t * 0.11);
    ctx.strokeStyle = 'rgba(20,14,8,.45)';
    ctx.beginPath();
    ctx.arc(p.x, p.y + t * 0.15, t * 0.52, 0, Math.PI * 2);
    ctx.stroke();
    ctx.strokeStyle = '#f6cf7a';
    ctx.beginPath();
    ctx.arc(p.x, p.y + t * 0.15, t * 0.52, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * c.ratio);
    ctx.stroke();
    ctx.restore();
  }

  /* ══════════ 고스트 미리보기 ══════════ */
  function drawGhost() {
    var pl = S.S.placing;
    if (!pl) return;
    var t = GM.camera.cam.tile;

    if (pl.kind === 'fence') {
      drawFenceGhost();
      return;
    }
    if (pl.kind === 'rail') {
      drawRailGhost();
      return;
    }
    if (hoverTile.x < 0) return;
    var v = GM.build ? GM.build.validate(pl, hoverTile.x, hoverTile.y) : { ok: true };
    /* ★ §12-1 — 고스트도 풋프린트 사각형 전체를 보여 준다 (놓기 전에 "얼마나 큰지"가 보여야 한다) */
    var key = pl.kind === 'build' ? pl.key : (pl.kind === 'relocate' ? pl.key : null);
    var f = key ? S.footprintOf(key) : { w: 1, h: 1 };
    var a0 = key ? S.anchorFromCell(key, hoverTile.x, hoverTile.y) : { x: hoverTile.x, y: hoverTile.y };
    var cxy = { x: a0.x + (f.w - 1) / 2, y: a0.y + (f.h - 1) / 2 };
    var p = GM.camera.worldToScreen(a0.x - 0.5, a0.y - 0.5);
    ctx.save();
    ctx.globalAlpha = 0.7;
    if (key) {
      var gw = t * (f.w + 0.7), gh = t * (f.h + 0.7);
      var gbase = cxy.y + (f.h - 1) / 2 + 0.55;
      var gp = GM.camera.worldToScreen(cxy.x - (f.w + 0.7) / 2 + 0.1, gbase - (f.h + 0.7));
      try {
        var gs = (S.buildingDef(key) || {}).hq ? GM.atlas.hall(S.tierNo()) : GM.atlas.building(key, 1);
        ctx.drawImage(gs, Math.round(gp.x), Math.round(gp.y), Math.ceil(gw), Math.ceil(gh));
      } catch (e) {}
    }
    ctx.globalAlpha = 0.4;
    ctx.fillStyle = v.ok ? '#6a994e' : '#bc4749';
    ctx.fillRect(p.x, p.y, t * f.w, t * f.h);
    ctx.globalAlpha = 1;
    ctx.lineWidth = 2;
    ctx.strokeStyle = v.ok ? '#8dfa8d' : '#ff9d99';
    ctx.strokeRect(p.x, p.y, t * f.w, t * f.h);
    ctx.restore();
    /* ★ §15-A-4 — 놓기 전에 어디까지 닿는지 보여 준다. 이것이 "터렛이 안 쏜다"의 예방약이다. */
    var tur = key ? S.turretSpecOf(key, 1) : null;
    if (tur && tur.range) rangeCircle(cxy.x, cxy.y, tur.range, v.ok ? '#f6cf7a' : '#ff9d99', true);
    var lby = a0.y - 1.25;
    if (!v.ok && v.reason) label(v.reason, cxy.x, lby, '#ff9d99');
    else if (v.ok && v.note) label(v.note, cxy.x, lby, '#b8f0a0');
    else if (tur && tur.range) label(turretReachNote(cxy.x, cxy.y, tur.range), cxy.x, lby, '#f6cf7a');

    if (pl.kind === 'reclaim' && pl.drag) {
      var a = pl.drag;
      var x0 = Math.min(a.x0, hoverTile.x), x1 = Math.max(a.x0, hoverTile.x);
      var y0 = Math.min(a.y0, hoverTile.y), y1 = Math.max(a.y0, hoverTile.y);
      var q = GM.camera.worldToScreen(x0 - 0.5, y0 - 0.5);
      ctx.save();
      ctx.globalAlpha = 0.3;
      ctx.fillStyle = '#e0c65a';
      ctx.fillRect(q.x, q.y, (x1 - x0 + 1) * t, (y1 - y0 + 1) * t);
      ctx.restore();
    }
  }

  /** 울타리 드래그 — 지금 긋고 있는 선을 미리 보여 준다 */
  function drawFenceGhost() {
    var t = GM.camera.cam.tile;
    var pts = fencePath ? fencePath.slice() : [];
    if (hoverTile.x >= 0) pts = pts.concat([{ x: hoverTile.x, y: hoverTile.y }]);
    if (!pts.length) return;
    ctx.save();
    ctx.globalAlpha = 0.85;
    for (var i = 0; i < pts.length; i++) {
      var okHere = GM.build ? GM.build.fenceTileOk(pts[i].x, pts[i].y) : true;
      var p = GM.camera.worldToScreen(pts[i].x - 0.5, pts[i].y - 0.5);
      ctx.fillStyle = okHere ? 'rgba(140,250,140,.35)' : 'rgba(220,90,90,.4)';
      ctx.fillRect(p.x, p.y, t, t);
      if (i > 0) {
        var a = GM.camera.worldToScreen(pts[i - 1].x, pts[i - 1].y);
        var b = GM.camera.worldToScreen(pts[i].x, pts[i].y);
        ctx.strokeStyle = '#a3703f';
        ctx.lineWidth = Math.max(3, t * 0.2);
        ctx.beginPath();
        ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y);
        ctx.stroke();
      }
    }
    ctx.restore();
    var cost = GM.build ? GM.build.fenceCostText(pts.length) : '';
    if (cost) label(cost, pts[pts.length - 1].x, pts[pts.length - 1].y - 1.2, '#f6cf7a');
  }

  /** ★ §13-D-5 — 철로 고스트. 지나간 칸이 그대로 놓일 자리다(선분이 아니다). */
  function drawRailGhost() {
    var t = GM.camera.cam.tile;
    var pts = fencePath ? fencePath.slice() : [];
    if (hoverTile.x >= 0) pts = pts.concat([{ x: hoverTile.x, y: hoverTile.y }]);
    if (!pts.length) return;
    ctx.save();
    ctx.globalAlpha = 0.8;
    for (var i = 0; i < pts.length; i++) {
      var okHere = GM.build ? GM.build.railTileOk(pts[i].x, pts[i].y) : true;
      var p = GM.camera.worldToScreen(pts[i].x - 0.5, pts[i].y - 0.5);
      ctx.fillStyle = okHere ? 'rgba(154,164,174,.5)' : 'rgba(220,90,90,.4)';
      ctx.fillRect(p.x, p.y, t, t);
    }
    ctx.restore();
    var cost = GM.build ? GM.build.railCostText(pts.length) : '';
    if (cost) label(cost, pts[pts.length - 1].x, pts[pts.length - 1].y - 1.2, '#c8d2dc');
  }

  function setFencePath(pts) { fencePath = pts; }
  function getFencePath() { return fencePath; }

  /* ══════════ 선택 표시 ══════════ */
  function ringAt(x, y, color, alpha) {
    var t = GM.camera.cam.tile;
    var p = GM.camera.worldToScreen(x, y);
    ctx.save();
    ctx.globalAlpha = alpha === undefined ? 1 : alpha;
    ctx.strokeStyle = color;
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(p.x, p.y, t * 0.62, 0, Math.PI * 2);
    ctx.stroke();
    ctx.restore();
  }

  /**
   * ★ GDD3 §15-A-4 — 터렛 사거리 원.
   *
   * 왜 이것이 P0 의 나머지 반쪽인가: §14-4 가 짐승을 영토 밖으로 못박은 뒤로, 본부 옆에 세운
   * 터렛은 **닿을 수가 없다**(실측: 영토 반경 16 · 사거리 7 · 짐승 최근접 11.05칸).
   * 그러니 "왜 안 쏘지"의 답은 코드만이 아니라 **눈**으로도 와야 한다 — 어디까지 닿는지를 그린다.
   * 영토 경계와 겹쳐 그려서, 원이 경계를 넘어야 바깥의 것에 닿는다는 사실이 한눈에 보이게 한다.
   */
  function rangeCircle(cx, cy, range, color, strong) {
    var t = GM.camera.cam.tile;
    var p = GM.camera.worldToScreen(cx, cy);
    var r = Math.max(2, range * t);
    ctx.save();
    ctx.globalAlpha = strong ? 0.16 : 0.10;
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.arc(p.x, p.y, r, 0, Math.PI * 2);
    ctx.fill();
    ctx.globalAlpha = strong ? 0.85 : 0.5;
    ctx.strokeStyle = color;
    ctx.lineWidth = 2;
    ctx.setLineDash([6, 5]);
    ctx.lineDashOffset = -(animT / 42) % 11;
    ctx.beginPath();
    ctx.arc(p.x, p.y, r, 0, Math.PI * 2);
    ctx.stroke();
    ctx.restore();
    if (t >= 16) label('사거리 ' + U.fmt(range, 0) + '칸', cx, cy - range - 0.5, color);
  }

  /**
   * ★ §15-A-4 — 이 자리에 세우면 영토 경계 **밖** 몇 칸까지 닿는가.
   * 짐승은 영토 안으로 못 들어온다(§14-4). 그래서 경계를 못 넘는 터렛은 평생 한 발도 못 쏜다 —
   * 그 사실을 놓기 전에 한 줄로 알려 준다.
   */
  function turretReachNote(cx, cy, range) {
    var t = S.territory();
    var R = t && t.radius;
    if (!t || t.cx == null || !R) return '사거리 ' + U.fmt(range, 0) + '칸';
    var toEdge = R - Math.hypot(cx - t.cx, cy - t.cy);
    var over = range - toEdge;
    if (over >= 0.5) return '경계 밖 ' + U.fmt(over, 0) + '칸까지 닿습니다';
    return '경계에 못 미칩니다 — 바깥 짐승에 닿지 않습니다';
  }

  function drawSelectionMarks() {
    var sel = S.S.selection;
    if (!sel) return;
    if (sel.nodeId) { var n = S.nodeById(sel.nodeId); if (n) ringAt(n.x, n.y, '#e8a33d'); }
    /* ★ §15-A-4 — 터렛을 누르면 사거리가 보인다 */
    if (sel.structureId) {
      var st = S.structureById ? S.structureById(sel.structureId) : null;
      if (st && st.turret && st.turret.range) {
        var c = S.centerOfThing(st);
        rangeCircle(c.x, c.y, st.turret.range, '#f6cf7a', true);
      }
    }
    if (dragBox) {
      ctx.save();
      ctx.strokeStyle = '#8dfa8d';
      ctx.lineWidth = 1.5;
      ctx.setLineDash([4, 3]);
      ctx.fillStyle = 'rgba(140,250,140,.12)';
      var x = Math.min(dragBox.x0, dragBox.x1), y = Math.min(dragBox.y0, dragBox.y1);
      var w = Math.abs(dragBox.x1 - dragBox.x0), h = Math.abs(dragBox.y1 - dragBox.y0);
      ctx.fillRect(x, y, w, h);
      ctx.strokeRect(x, y, w, h);
      ctx.restore();
    }
    /* 손이 닿는 대상 — 지금 E 를 누르면 무엇을 하는가 */
    if (GM.swing) {
      var tgt = GM.swing.target();
      if (tgt) {
        ctx.save();
        ctx.globalAlpha = 0.5 + 0.3 * Math.sin(animT / 240);
        ringAt(tgt.x, tgt.y, '#8dfa8d', 1);
        ctx.restore();
      }
    }
  }

  /* ══════════ 밤낮 조명 4구간 — ★ GDD3 §12-10 대비 강화 ══════════
     ① 구간 전체에 걸쳐 부드럽게 섞는다(옛 코드는 마지막 25%에서만 이어 붙여 계단이 보였다)
     ② 새벽·노을에는 하늘 쪽(위)과 땅 쪽(아래)이 다른 색으로 물드는 세로 그라데이션을 얹는다
     ③ 밤에는 모닥불·본부·가로등·집 창문이 실제로 빛난다 */
  function phaseBlend() {
    var f = U.clamp(S.S.dayFraction || 0, 0, 1);
    var pos = f * 4;
    var i = Math.min(3, Math.floor(pos));
    var local = pos - i;
    var cur = S.DAY_PHASES[i];
    var nxt = S.DAY_PHASES[(i + 1) % 4];
    /* 구간의 한가운데를 '그 구간다운' 색으로 두고, 앞뒤 25%를 이웃과 섞는다 */
    var k = local < 0.25 ? (0.5 - local * 2) : (local > 0.75 ? (local - 0.75) * 2 : 0);
    var toward = local < 0.25 ? S.DAY_PHASES[(i + 3) % 4] : nxt;
    /* ★ §14-2 — 자료의 값에 플레이어의 밝기 슬라이더를 곱한다(1.0 이면 자료 그대로) */
    var dark = S.darkScale();
    var lift = S.liftBonus();
    return {
      idx: i,
      alpha: Math.max(0, U.lerp(cur.alpha, toward.alpha, k) * dark),
      tint: k > 0 ? U.mix(cur.tint, toward.tint, k) : cur.tint,
      /* ★ §13-A-2 — 어둠(alpha)과 나란히 빛(lift)도 섞는다. 낮은 따뜻하게, 밤은 달빛으로. */
      lift: Math.max(0, U.lerp(cur.lift || 0, toward.lift || 0, k) + lift),
      liftColor: k > 0 ? U.mix(cur.liftColor || '#ffffff', toward.liftColor || '#ffffff', k) : (cur.liftColor || '#ffffff'),
      sky: cur.sky, ground: cur.ground,
      skyK: (1 - Math.abs(local - 0.5) * 0.8) * dark,
      dark: dark
    };
  }

  function drawDayNight() {
    var ph = phaseBlend();
    if (ph.alpha >= 0.01) {
      ctx.save();
      ctx.globalAlpha = ph.alpha;
      ctx.fillStyle = ph.tint;
      ctx.fillRect(0, 0, W, H);
      ctx.restore();
    }
    /* ★ §13-A-2 밝기 하한 — 어둠을 덜어 내는 것만으로는 낮이 밝아지지 않는다(낮은 이미 alpha 0).
       그래서 빛을 **더한다**. 밤에는 이 항이 달빛이 되어 칠흑을 막는 바닥이 된다. */
    if (ph.lift >= 0.005) {
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      ctx.globalAlpha = ph.lift;
      ctx.fillStyle = ph.liftColor;
      ctx.fillRect(0, 0, W, H);
      ctx.restore();
    }
    /* ② 새벽·노을 그라데이션 */
    if (ph.sky || ph.ground) {
      var g0 = null;
      try {
        g0 = ctx.createLinearGradient(0, 0, 0, H);
        g0.addColorStop(0, ph.sky || 'rgba(0,0,0,0)');
        g0.addColorStop(0.52, 'rgba(0,0,0,0)');
        g0.addColorStop(1, ph.ground || 'rgba(0,0,0,0)');
      } catch (e) { g0 = null; }
      if (g0) {
        ctx.save();
        ctx.globalAlpha = ph.skyK;
        ctx.fillStyle = g0;
        ctx.fillRect(0, 0, W, H);
        ctx.restore();
      }
    }
    /* ③ 밤 광원 — 모닥불·본부·가로등·창문
       ★ §13-A-2 — 세기를 밤 어둠(다이얼) 대비 상대값으로 잰다. 밤을 완화해도 등불은 그대로 밝다. */
    /* 밤 어둠의 최대치도 밝기 슬라이더를 탄다 — 밝게 해도 등불이 꺼지지 않게 같은 자로 잰다(§14-2) */
    var maxA = (((S.DAY_PHASES[3] && S.DAY_PHASES[3].alpha) || 0.44) * (ph.dark || 1)) || 0.01;
    var lightOn = maxA * 0.45;
    if (ph.idx !== 3 && ph.alpha < lightOn) return;
    var strength = U.clamp((ph.alpha - lightOn) / Math.max(0.01, maxA - lightOn), 0, 1);
    if (strength <= 0.02) return;
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    var t = GM.camera.cam.tile;
    var lights = 0;
    S.structures().forEach(function (b) {
      if (lights >= 18) return;                        // 등불 상한 — 60fps 예산
      if (b.x == null) return;
      var c = S.centerOfThing(b);
      if (!GM.camera.onScreen(c.x, c.y, t * 5)) return;
      var kind = b.hq ? 'hq' : (b.key === 'lamp' ? 'lamp'
        : (b.key === 'campfire' ? 'fire' : (LIT_HOUSES[b.key] ? 'window' : null)));
      if (!kind) return;
      lights++;
      var p = GM.camera.worldToScreen(c.x, c.y);
      var flick = kind === 'window' ? 1 : (0.92 + 0.08 * Math.sin(animT / (kind === 'lamp' ? 520 : 190) + c.x));
      var r = t * (kind === 'hq' ? 5.4 + S.tierNo() * 0.4 : (kind === 'fire' ? 4.6 : (kind === 'lamp' ? 3.4 : 2.4))) * flick;
      var g;
      try {
        g = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, r);
        g.addColorStop(0, kind === 'window' ? 'rgba(255,214,150,.26)' : 'rgba(255,190,110,.42)');
        g.addColorStop(1, 'rgba(255,190,110,0)');
      } catch (e) { g = null; }
      if (!g) return;
      ctx.globalAlpha = strength;
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(p.x, p.y, r, 0, Math.PI * 2);
      ctx.fill();
    });
    ctx.restore();
  }

  /* 밤에 창문이 켜지는 건물 — 사람이 사는 곳과 불을 쓰는 곳 */
  var LIT_HOUSES = { tent: 1, hut: 1, house: 1, manor: 1, granary: 1, smithy: 1, smelter: 1,
                     barracks: 1, market: 1, trading_post: 1, shrine: 1, consulate: 1, appraisal_post: 1 };

  /* ══════════ 라벨 ══════════ */
  function label(text, wx, wy, color) {
    var p = GM.camera.worldToScreen(wx, wy);
    if (p.x < -80 || p.y < -20 || p.x > W + 80 || p.y > H + 20) return;
    ctx.save();
    ctx.font = '11px "Galmuri11", monospace';
    ctx.textAlign = 'center';
    var w = 0;
    try { w = ctx.measureText(text).width; } catch (e) { w = String(text).length * 6; }
    ctx.fillStyle = 'rgba(20,14,8,.62)';
    ctx.fillRect(p.x - w / 2 - 3, p.y - 11, w + 6, 14);
    ctx.fillStyle = color || '#f4e4bc';
    try { ctx.fillText(text, p.x, p.y); } catch (e2) {}
    ctx.restore();
  }

  /* ══════════ 지도가 아직 없을 때 ══════════ */
  function drawBootNotice() {
    var b = S.S.boot || { phase: 'waiting' };
    var failed = b.phase === 'failed';
    var title = b.title || '땅을 살피는 중…';
    var hint = b.hint || null;
    ctx.textAlign = 'center';
    ctx.fillStyle = failed ? '#e8a08a' : '#8a8496';
    ctx.font = '15px "Galmuri11", monospace';
    try { ctx.fillText(title, W / 2, H / 2 - (hint ? 12 : 0)); } catch (e) {}
    if (hint) {
      ctx.fillStyle = failed ? '#c8a08a' : '#6f6a7c';
      ctx.font = '12px "Galmuri11", monospace';
      var words = String(hint).split(' ');
      var lines = [''], max = Math.max(18, Math.floor(W / 13));
      for (var i = 0; i < words.length; i++) {
        var t = lines[lines.length - 1];
        if ((t + ' ' + words[i]).trim().length > max && lines.length < 3) lines.push(words[i]);
        else lines[lines.length - 1] = (t + ' ' + words[i]).trim();
      }
      for (var k = 0; k < lines.length; k++) {
        try { ctx.fillText(lines[k], W / 2, H / 2 + 12 + k * 17); } catch (e2) {}
      }
    }
  }

  /* ══════════ ★ 안내 시스템 (GDD3 §11-3) ══════════ */
  /* 「뭘 해야 할지 모르는 순간 제로」의 화면 몫.
     ① 아바타 곁의 대상에 상호작용 라벨을 띄우고
     ② 목표 카드가 가리키는 자리에 바운스 화살표를, 화면 밖이면 가장자리 화살표를 세운다. */

  var VERB = {
    forest: 'E — 나무 베기', rock: 'E — 돌 캐기', iron: 'E — 광맥 캐기', oil: 'E — 기름 긷기',
    water: 'E — 물고기 잡기', fertile: 'E — 거두기', field: 'E — 거두기', ruin: 'E — 유적 살피기',
    berry: 'E — 열매 따기', site: 'E — 짓기', enemy: 'E — 베기', wild: 'E — 사냥하기'
  };

  function verbFor(t) {
    if (!t) return null;
    if (t.kind === 'enemy') return VERB.enemy;
    if (t.kind === 'wild') return 'E — ' + (t.obj && t.obj.name ? t.obj.name : '짐승') + ' 사냥';
    if (t.kind === 'site') {
      var name = t.obj && t.obj.name ? t.obj.name : '공사';
      return 'E — ' + name + ' 짓기';
    }
    return VERB[t.nodeType] || 'E — 일하기';
  }

  /** ① 근처 대상 상호작용 라벨 — 손이 닿는 것 하나에만 붙는다 */
  function drawInteractPrompt() {
    if (!GM.swing || !GM.swing.target) return;
    if (GM.opening && GM.opening.busy && GM.opening.busy()) return;
    var t = GM.swing.target();
    if (!t) return;
    var txt = verbFor(t);
    if (!txt) return;
    var p = GM.camera.worldToScreen(t.x, t.y);
    var tile = GM.camera.cam.tile;
    var y = p.y - tile * 1.15;
    var bob = Math.sin(animT / 260) * 2;
    ctx.save();
    ctx.font = '12px Galmuri11, monospace';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    var w = ctx.measureText(txt).width + 14;
    var ready = GM.swing.ready && GM.swing.ready();
    ctx.globalAlpha = 0.92;
    ctx.fillStyle = 'rgba(16,12,22,.82)';
    ctx.fillRect(Math.round(p.x - w / 2), Math.round(y - 10 + bob), Math.round(w), 20);
    ctx.strokeStyle = ready ? 'rgba(246,207,122,.9)' : 'rgba(150,140,120,.6)';
    ctx.lineWidth = 1;
    ctx.strokeRect(Math.round(p.x - w / 2) + 0.5, Math.round(y - 10 + bob) + 0.5, Math.round(w) - 1, 19);
    ctx.fillStyle = ready ? '#f6e6a8' : '#b8ae9c';
    ctx.globalAlpha = 1;
    try { ctx.fillText(txt, p.x, y + bob); } catch (e) {}
    ctx.restore();
  }

  /** ② 퀘스트 마커 — 목표 카드가 가리키는 자리 */
  function drawQuestMarkers() {
    if (!S.goalTargets) return;
    if (GM.opening && GM.opening.busy && GM.opening.busy()) return;
    var prog = S.goalProgress && S.goalProgress();
    if (prog && prog.done) return;
    var list = S.goalTargets().filter(function (t) { return t && t.x != null && t.y != null; });
    if (!list.length) return;
    var tile = GM.camera.cam.tile;
    var bob = Math.abs(Math.sin(animT / 380)) * Math.max(3, tile * 0.22);

    for (var i = 0; i < list.length; i++) {
      var g = list[i];
      var p = GM.camera.worldToScreen(g.x, g.y);
      var onScreen = p.x >= 8 && p.y >= 8 && p.x <= W - 8 && p.y <= H - 8;
      var alpha = i === 0 ? 1 : 0.45;                 // 첫 후보가 주인공, 나머지는 예비
      if (onScreen) {
        drawBounceArrow(p.x, p.y - tile * 0.9 - bob, alpha, i === 0);
        if (i === 0) {
          ctx.save();
          ctx.globalAlpha = 0.35 + Math.sin(animT / 300) * 0.12;
          ctx.strokeStyle = '#f6cf7a';
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.arc(p.x, p.y, tile * 0.66, 0, Math.PI * 2);
          ctx.stroke();
          ctx.restore();
        }
      } else if (i === 0) {
        drawEdgeArrow(p.x, p.y, g);
      }
    }
  }

  function drawBounceArrow(x, y, alpha, big) {
    var s = big ? 9 : 6;
    ctx.save();
    ctx.globalAlpha = alpha;
    ctx.fillStyle = '#f6cf7a';
    ctx.strokeStyle = 'rgba(20,14,8,.8)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(x, y + s);
    ctx.lineTo(x - s, y - s);
    ctx.lineTo(x + s, y - s);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.restore();
  }

  /** 화면 밖이면 가장자리에서 방향을 가리킨다 (거리도 함께) */
  function drawEdgeArrow(sx, sy, g) {
    var m = 26;
    var cx = W / 2, cy = H / 2;
    var dx = sx - cx, dy = sy - cy;
    var len = Math.hypot(dx, dy) || 1;
    var kx = (W / 2 - m) / Math.abs(dx || 1e-6);
    var ky = (H / 2 - m) / Math.abs(dy || 1e-6);
    var k = Math.min(kx, ky);
    var ex = cx + dx * k, ey = cy + dy * k;
    var ang = Math.atan2(dy, dx);
    var me = GM.avatar && GM.avatar.pos();
    var tiles = me ? Math.round(Math.hypot(g.x - me.x, g.y - me.y)) : null;

    ctx.save();
    ctx.translate(ex, ey);
    ctx.rotate(ang);
    ctx.globalAlpha = 0.85 + Math.sin(animT / 300) * 0.12;
    ctx.fillStyle = '#f6cf7a';
    ctx.strokeStyle = 'rgba(20,14,8,.85)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(12, 0);
    ctx.lineTo(-8, -8);
    ctx.lineTo(-4, 0);
    ctx.lineTo(-8, 8);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.restore();

    if (tiles != null) {
      ctx.save();
      ctx.font = '11px Galmuri11, monospace';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillStyle = 'rgba(16,12,22,.8)';
      var lbl = tiles + '칸';
      var w2 = ctx.measureText(lbl).width + 10;
      ctx.fillRect(Math.round(ex - w2 / 2), Math.round(ey + 12), Math.round(w2), 16);
      ctx.fillStyle = '#f6e6a8';
      try { ctx.fillText(lbl, ex, ey + 20); } catch (e) {}
      ctx.restore();
    }
  }

  /* ══════════ 프레임 ══════════ */
  function draw() {
    if (!ctx) return;
    ctx.setTransform(Math.min(global.devicePixelRatio || 1, 2), 0, 0, Math.min(global.devicePixelRatio || 1, 2), 0, 0);
    ctx.imageSmoothingEnabled = false;
    ctx.fillStyle = '#08060e';
    ctx.fillRect(0, 0, W, H);
    if (!S.S.map) { drawBootNotice(); return; }

    var sh = GM.fx ? GM.fx.shakeOffset() : { x: 0, y: 0 };
    if (sh.x || sh.y) ctx.translate(sh.x, sh.y);

    var tile = GM.camera.cam.tile;
    drawTerrain();
    drawClusters();
    drawTerritory();
    if (GM.fx) GM.fx.drawStumps(ctx, tile);
    drawRails();                         /* ★ §13-D-5 — 바닥에 깔린 것이 먼저다 */
    drawNodes();
    drawFences();
    drawStructures();
    drawCamps();
    drawMoveMarker();
    drawWild();
    drawResidents();
    if (GM.combat && GM.combat.drawUnits) GM.combat.drawUnits(ctx, tile, animT);
    drawAvatars();
    drawCooldownRing();
    drawFog();
    drawDayNight();
    drawSelectionMarks();
    drawGhost();
    // ★ 안내 시스템 — 안개·조명 위에 얹는다(어두워도 길잡이는 또렷해야 한다)
    drawInteractPrompt();
    drawQuestMarkers();
    if (GM.fx) GM.fx.drawWorld(ctx, tile);
    if (GM.combat && GM.combat.drawOverlay) GM.combat.drawOverlay(ctx, W, H, animT);
    if (GM.opening && GM.opening.drawOverlay) GM.opening.drawOverlay(ctx, W, H, animT);
  }

  function tickAnim(t) {
    var raw = lastT ? (t - lastT) : 16;
    var dt = lastT ? Math.min(0.05, raw / 1000) : 0.016;
    lastT = t;
    animT = t;
    frameTimes.push(raw);
    if (frameTimes.length > 240) frameTimes.shift();
    /* ★ 한 프레임을 만드는 데 실제로 든 시간. 프레임 간격(raw)은 60fps 로 맞물리면 늘 16.7ms 라
       그것만으로는 여유가 있는지 알 수 없다 — 그리는 일 자체의 값을 따로 잰다. */
    var w0 = (global.performance && performance.now) ? performance.now() : Date.now();

    var frozen = GM.fx && GM.fx.frozen();
    GM.camera.update(dt);
    if (!frozen) {
      stepUnits(dt);
      stepWild(dt);
      stepMates(dt);        // ★ §15-C — 동료와 동료들의 걸음(1초 좌표 사이를 등속으로)
      if (GM.avatar) GM.avatar.step(dt);
      if (GM.swing) GM.swing.step(dt);
      if (GM.combat && GM.combat.step) GM.combat.step(dt);
      if (GM.opening && GM.opening.step) GM.opening.step(dt);
      if (territoryAnim) {
        territoryAnim.t += dt;
        if (territoryAnim.t > 1.8) territoryAnim = null;
      }
      stakePhase += dt;
    }
    if (GM.input) GM.input.step(dt);
    if (GM.fx) GM.fx.step(dt);
    draw();
    if (GM.fx) GM.fx.drawLayer();
    if (GM.minimap) GM.minimap.draw();

    var w1 = (global.performance && performance.now) ? performance.now() : Date.now();
    workTimes.push(w1 - w0);
    if (workTimes.length > 240) workTimes.shift();
  }

  function stat(list) {
    if (!list.length) return { avg: 0, p95: 0, n: 0 };
    var a = list.slice().sort(function (x, y) { return x - y; });
    var sum = 0;
    for (var i = 0; i < a.length; i++) sum += a[i];
    return { avg: sum / a.length, p95: a[Math.floor(a.length * 0.95)], n: a.length };
  }

  /**
   * 스모크·개발 패널이 읽는 프레임 통계 (밀리초).
   *   avg·p95 — 프레임 **간격**. 60fps 로 맞물려 돌면 16.7ms 근처가 정상이다(작을수록 좋은 값이 아니다).
   *   work    — 한 프레임을 실제로 **그리는 데 든 시간**. 16.7ms 예산 대비 여유가 이 값으로 보인다.
   */
  function frameStats() {
    var f = stat(frameTimes);
    var w = stat(workTimes);
    return { avg: f.avg, p95: f.p95, n: f.n, workAvg: w.avg, workP95: w.p95 };
  }
  function resetStats() { frameTimes = []; workTimes = []; }

  function setHover(x, y) { hoverTile.x = x; hoverTile.y = y; }
  function hover() { return hoverTile; }
  function setDragBox(b) { dragBox = b; }
  function reset() {
    chunkCache = {}; units = {}; walkIns = []; doneBounce = {}; territoryAnim = null;
    structSort = { sig: '', list: [] };
    wild = {};
  }

  /** 사냥 대상 고르기 — 아바타에서 사거리 안, 가장 가까운 놈 (§13-C-8)
      ★ §16-4 — 화면 자리(보간, 한 스텝 뒤)와 서버 자리(제일 새 좌표) **중 가까운 쪽**으로 잰다.
      화면만 보면 쫓아오는 놈이 아직 멀어 보여 대상조차 안 잡히고, 서버만 보면 눈앞의 놈이
      안 잡힌다 — 판정은 어차피 서버가 다시 한다(huntSwing 의 지금·직전 괄호). */
  function nearestWild(x, y, range) {
    var list = S.creatureList();
    var best = null;
    var bestD = Infinity;
    for (var i = 0; i < list.length; i++) {
      var c = list[i];
      var a = wild[c.id] || c;
      var d = Math.min(Math.hypot(a.x - x, a.y - y), Math.hypot(c.x - x, c.y - y));
      if (d < bestD) { bestD = d; best = { c: c, d: d, x: a.x, y: a.y }; }
    }
    if (!best || (range != null && best.d > range)) return null;
    return best;
  }
  function wildPos(id) { return wild[id] || null; }

  GM.world = {
    mount: mount, resize: resize, draw: draw, tickAnim: tickAnim,
    setHover: setHover, hover: hover, setDragBox: setDragBox, recenter: recenter, reset: reset,
    animateTerritory: animateTerritory, bounceStructure: bounceStructure, markArrival: markArrival,
    setFencePath: setFencePath, getFencePath: getFencePath,
    /* ★ §16-7 — 마차 동반 하차: 오프닝이 걷히는 순간 동료들이 마차 자리에서 내린다 */
    crewDisembark: crewDisembark,
    /* ★ §16-12 — 동료·다른 사람의 화면 자리(보간) — 스윙 팝을 그 사람 곁에 띄울 때 쓴다 */
    matePos: function (id) { return mates[id] || null; },
    nearestWild: nearestWild, wildPos: wildPos, markWildHurt: markWildHurt,
    /* ★ GDD3 §14-1 — 주민 작업 사이클의 수치 표시 */
    creditFloat: creditFloat,
    /* ★ GDD3 §15-A-2 — 터렛이 잡은 자리에 뜨는 수치 */
    turretKillFloat: turretKillFloat,
    /* ★ GDD3 §14-3 — 서버 좌표 묶음이 올 때마다 지연 버퍼를 한 칸 민다 */
    pushWild: pushWildSnapshot,
    /* 하니스·스모크 전용 — jsdom 에는 rAF 시계가 없어 걸음을 손으로 돌린다 */
    stepWildForTest: stepWild,
    label: label, ringAt: ringAt, verbFor: verbFor,
    frameStats: frameStats, resetStats: resetStats,
    size: function () { return { w: W, h: H }; },
    unitPos: function (id) { return units[id] || null; },
    /* ★ §12-11 회귀 하니스 전용 — jsdom 에는 rAF 시계가 없어 걸음을 손으로 돌린다 */
    stepUnitsForTest: stepUnits,
    ping: function (x, y, color) { if (GM.fx) GM.fx.ring(x, y, color || '#8dfa8d'); }
  };
})(window);
